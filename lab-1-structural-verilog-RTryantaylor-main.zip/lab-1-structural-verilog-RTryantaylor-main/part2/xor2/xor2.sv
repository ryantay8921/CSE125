module xor2
  (input [0:0] a_i
  ,input [0:0] b_i
  ,output [0:0] c_o);


      wire notA, notB;
      wire temp1_w, temp2_w;

      inv #() invA(.a_i(a_i), .b_o(notA));
      inv #() invB(.a_i(b_i), .b_o(notB));

      
      and2 #() and2_1(.a_i(a_i), .b_i(notB), .c_o(temp1_w));
      and2 #() and2_2(.a_i(notA), .b_i(b_i), .c_o(temp2_w));

      or2 #() or2(.a_i(temp1_w), .b_i(temp2_w), .c_o(c_o));


      

endmodule
