module mux2
  (input [0:0] a_i
  ,input [0:0] b_i
  ,input [0:0] select_i
  ,output [0:0] c_o);

   // Your code here:

  wire A_and_notS, notS, B_and_S;

  inv #() inv_S(.a_i(select_i), .b_o(notS));
  and2 #() and2_A_and_S(.a_i(a_i), .b_i(notS), .c_o(A_and_notS));
  and2 #() and2_B_and_notS(.a_i(b_i), .b_i(select_i), .c_o(B_and_S));
  or2 #() or2(.a_i(A_and_notS), .b_i(B_and_S), .c_o(c_o));


endmodule
