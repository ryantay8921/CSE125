module full_add
  (input [0:0] a_i
  ,input [0:0] b_i
  ,input [0:0] carry_i
  ,output [0:0] carry_o
  ,output [0:0] sum_o);

  wire carry1_w, temp1_w, temp2_w;

  half_add #() half_add1(.a_i(a_i), .b_i(b_i), .carry_o(temp1_w), .sum_o(carry1_w));
  half_add #() half_add2(.a_i(carry_i), .b_i(carry1_w), .carry_o(temp2_w), .sum_o(sum_o));

  or2 #() or2(.a_i(temp1_w), .b_i(temp2_w), .c_o(carry_o));


endmodule
