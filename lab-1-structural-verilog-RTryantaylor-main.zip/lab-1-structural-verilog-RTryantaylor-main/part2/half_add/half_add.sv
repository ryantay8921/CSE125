module half_add
  (input [0:0] a_i
  ,input [0:0] b_i
  ,output [0:0] carry_o
  ,output [0:0] sum_o);


  xor2#() xor2(.a_i(a_i), .b_i(b_i), .c_o(sum_o));
  and2#() and2(.a_i(a_i), .b_i(b_i), .c_o(carry_o));

endmodule
