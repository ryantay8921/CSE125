module adder
  #(parameter width_p = 5)
  // You must fill in the bit widths of a_i, b_i and sum_o. a_i and
  // b_i must be width_p bits.
  (input [width_p-1:0] a_i
  ,input [width_p-1:0] b_i
  ,output [width_p:0] sum_o);


  wire [width_p:0] carry_out_w;
  assign carry_out_w[0] = 1'b0;

  wire [width_p-1:0] sum_carry;
  genvar i;
  generate
    for(i = 0; i < width_p; i++) begin
      full_add #() full_add_i(.a_i(a_i[i]), .b_i(b_i[i]), .carry_i(carry_out_w[i]), 
                              .carry_o(carry_out_w[i+1]), .sum_o(sum_carry[i]));
    end
  endgenerate

  assign sum_o = {carry_out_w[width_p], sum_carry[width_p-1:0]};


endmodule
