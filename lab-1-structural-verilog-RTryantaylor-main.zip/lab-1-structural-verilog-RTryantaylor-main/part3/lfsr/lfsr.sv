module lfsr
   (input [0:0] clk_i
   ,input [0:0] reset_i
   ,input [0:0] en_i
   ,output [8:0] data_o);

   // wire [8:0] q;
   // wire [0:0] feedback;
   // xor2 #() xor2(.a_i(q[3]), .b_i(q[8]), .c_o(feedback));

   //  dff #(.reset_val_p(1'b0)) dff_0(.clk_i(clk_i), .reset_i(reset_i), .d_i(feedback), .en_i(en_i), .q_o(q[0]));
   //  dff #(.reset_val_p(1'b0)) dff_1(.clk_i(clk_i), .reset_i(reset_i), .d_i(q[0]), .en_i(en_i), .q_o(q[1]));
   //  dff #(.reset_val_p(1'b0)) dff_2(.clk_i(clk_i), .reset_i(reset_i), .d_i(q[1]), .en_i(en_i), .q_o(q[2]));
   //  dff #(.reset_val_p(1'b0)) dff_3(.clk_i(clk_i), .reset_i(reset_i), .d_i(q[2]), .en_i(en_i), .q_o(q[3]));
   //  dff #(.reset_val_p(1'b0)) dff_4(.clk_i(clk_i), .reset_i(reset_i), .d_i(q[3]), .en_i(en_i), .q_o(q[4]));
   //  dff #(.reset_val_p(1'b0)) dff_5(.clk_i(clk_i), .reset_i(reset_i), .d_i(q[4]), .en_i(en_i), .q_o(q[5]));
   //  dff #(.reset_val_p(1'b0)) dff_6(.clk_i(clk_i), .reset_i(reset_i), .d_i(q[5]), .en_i(en_i), .q_o(q[6]));
   //  dff #(.reset_val_p(1'b0)) dff_7(.clk_i(clk_i), .reset_i(reset_i), .d_i(q[6]), .en_i(en_i), .q_o(q[7]));
   //  dff #(.reset_val_p(1'b1)) dff_8(.clk_i(clk_i), .reset_i(reset_i), .d_i(q[7]), .en_i(en_i), .q_o(q[8]));

   // assign data_o = q;


      logic feedback;
      logic [8:0] q;
      shift #(.depth_p(9), .reset_val_p('b000000001)) lfsr(.clk_i(clk_i), .reset_i(reset_i), .data_i(feedback), .enable_i(en_i), .data_o(q));
      xor2 #() xor2(.a_i(q[3]), .b_i(q[8]), .c_o(feedback));

      assign data_o = q;


endmodule
