module inv_bus
  #(parameter width_p = 1)
  (input [width_p-1:0] a_i,
   output [width_p-1:0] b_o);

    assign b_o = ~a_i;


endmodule
