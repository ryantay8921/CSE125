module counter
  #(parameter width_p = 4)
   (input [0:0] clk_i
   ,input [0:0] reset_i
   ,input [0:0] up_i
   ,input [0:0] down_i
   ,output [width_p-1:0] count_o);

  genvar i;

  logic [width_p-1:0] next_count, count_d, count_down, count_up;
  logic enable_ff;

  xor2 #() xor2(.a_i(up_i), .b_i(down_i), .c_o(enable_ff)); //enables ff's to count, does nothing when nothing is high and when both are high
  for (i = 0; i < width_p; i++) begin : dff_mux_array
    dff #(.reset_val_p(1'b0)) dff_inst(.clk_i(clk_i), .reset_i(reset_i), .d_i(next_count[i]), .en_i(enable_ff), .q_o(count_d[i]));
    mux2 #() mux_inst(.select_i(up_i & enable_ff), .a_i(count_down[i]), .b_i(count_up[i]), .c_o(next_count[i]));
  end

  adder #(.width_p(width_p)) adder_up_inst(.a_i(count_d), .b_i({{width_p-1{1'b0}}, 1'b1}), .sum_o(sum_o_carry_up));  
  adder #(.width_p(width_p)) adder_down_inst(.a_i(count_d), .b_i({width_p{1'b1}}), .sum_o({sum_o_carry_down}));

  logic [width_p:0] sum_o_carry_up, sum_o_carry_down;
  assign count_up = sum_o_carry_up[width_p-1:0];
  assign count_down = sum_o_carry_down[width_p-1:0];


  assign count_o = count_d;



endmodule
