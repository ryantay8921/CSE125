`timescale 1ns/1ps

`define START_TESTBENCH error_o = 0; pass_o = 0; #10;
`define FINISH_WITH_FAIL error_o = 1; pass_o = 0; #10; $finish();
`define FINISH_WITH_PASS pass_o = 1; error_o = 0; #10; $finish();
module testbench
  // You don't usually have ports in a testbench, but we need these to
  // signal to cocotb/gradescope that the testbench has passed, or failed.
  (output logic error_o = 1'bx
  ,output logic pass_o = 1'bx);

   localparam width_lp = 1;
   logic [width_lp-1:0] a_i;
   logic [width_lp-1:0] b_i;
   logic [width_lp-1:0] c_o;
   logic [width_lp-1:0] c_o_expected;

   // You can use this 
   logic [0:0] error;
   logic [31:0] itervar;
   logic fail; 
   // Write your assertions inside of the DUT modules themselves.
   xnor2 #() dut (.a_i(a_i) ,.b_i(b_i) ,.c_o(c_o));
   assign c_o_expected = (~(a_i ^ b_i));
   // assign c_o_expected = ((a_i ^ b_i));

   initial begin
      // Call this to set pass_o and error_o to 0.
      `START_TESTBENCH
      // Put your testbench code here. Print all of the test cases and
      // their correctness.
      #1;
       fail = 0;
      for(itervar = 0; itervar<3'b100; itervar++) begin
        a_i = itervar[0];
        b_i = itervar[1];
        #1;
        if(c_o !== c_o_expected) begin
          $display("FAILED: Got: %b; Expected: %b", c_o, c_o_expected);
          $display("FAILED: A_got: %b; B_got: %b", a_i, b_i);
          fail = 1;
        end
      end



      // Use FINISH_WITH_FAIL to end the testbench and cause the FAIL message, and signal fail to cocotb
      // Use FINISH_WITH_PASS to end the testbench and cause the PASS message, and signal pass to cocotb
      // Calling neither will cause the UNKNOWN message, and cause issues in Cocotb.
      if(fail) begin
         $display("FAIL: Got: %b; Expected: %b", c_o, c_o_expected);
         `FINISH_WITH_FAIL;
      end else if(~fail) begin
      `FINISH_WITH_PASS;
   end
end

   // This block executes after $finish() has been called.
   final begin
      $display("Simulation time is %t", $time);
      if(error_o === 1) begin
	 $display("\033[0;31m    ______                    \033[0m");
	 $display("\033[0;31m   / ____/_____________  _____\033[0m");
	 $display("\033[0;31m  / __/ / ___/ ___/ __ \\/ ___/\033[0m");
	 $display("\033[0;31m / /___/ /  / /  / /_/ / /    \033[0m");
	 $display("\033[0;31m/_____/_/  /_/   \\____/_/     \033[0m");
	 $display("Simulation Failed");
     end else if (pass_o === 1) begin
	 $display("\033[0;32m    ____  ___   __________\033[0m");
	 $display("\033[0;32m   / __ \\/   | / ___/ ___/\033[0m");
	 $display("\033[0;32m  / /_/ / /| | \\__ \\\__ \ \033[0m");
	 $display("\033[0;32m / ____/ ___ |___/ /__/ / \033[0m");
	 $display("\033[0;32m/_/   /_/  |_/____/____/  \033[0m");
	 $display("Simulation Succeeded!");
     end else begin
        $display("   __  ___   ____ __ _   ______ _       ___   __");
        $display("  / / / / | / / //_// | / / __ \\ |     / / | / /");
        $display(" / / / /  |/ / ,<  /  |/ / / / / | /| / /  |/ / ");
        $display("/ /_/ / /|  / /| |/ /|  / /_/ /| |/ |/ / /|  /  ");
        $display("\\____/_/ |_/_/ |_/_/ |_/\\____/ |__/|__/_/ |_/   ");
	$display("Please set error_o or pass_o!");
     end
   end

endmodule
