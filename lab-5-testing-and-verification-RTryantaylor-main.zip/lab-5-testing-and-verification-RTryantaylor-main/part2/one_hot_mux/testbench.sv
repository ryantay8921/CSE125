// CORRECT MODULE:
// one_hot_mux3.sv

`timescale 1ns/1ps

`define START_TESTBENCH error_o = 0; pass_o = 0; #10;
`define FINISH_WITH_FAIL error_o = 1; pass_o = 0; #10; $finish();
`define FINISH_WITH_PASS pass_o = 1; error_o = 0; #10; $finish();

module testbench
  #(parameter width_p = 8)
  (output logic error_o = 1'bx,
   output logic pass_o = 1'bx);

   logic [0:0] error;
   logic [31:0] itervar;
   logic fail; 

   // Declare signals
   logic [width_p-1:0] vec_i;
   logic [width_p-1:0] sel_i;
   logic out_o;
   logic expected_out_o;

   // Instantiate the DUT
   one_hot_mux dut (
       .vec_i(vec_i),
       .sel_i(sel_i),
       .out_o(out_o)
   );

   always_comb begin
      expected_out_o = 'x;
      for (int j = 0; j < width_p; j++) begin
          if (sel_i[j]) begin
              expected_out_o = vec_i[j];
              break;
          end
      end
   end

   int num_vec_tests;

   initial begin
      // Call this to set pass_o and error_o to 0.
      `START_TESTBENCH

      fail = 0;

      num_vec_tests = 50;

      for (int vec_test_num = 0; vec_test_num < num_vec_tests; vec_test_num++) begin
          vec_i = vec_test_num[width_p-1:0];
          for (itervar = 0; itervar < (1 << width_p); itervar++) begin
              sel_i = itervar[width_p-1:0];
              if ($countones(sel_i) != 1)
                  continue;
              #1;
              if (out_o !== expected_out_o) begin
                  $display("Test failed for sel_i = %b, vec_i = %b, expected out_o = %b, got out_o = %b",
                           sel_i, vec_i, expected_out_o, out_o);
                  fail = 1;
              end else begin
                  $display("Test passed for sel_i = %b, vec_i = %b, out_o = %b",
                           sel_i, vec_i, out_o);
              end
          end
      end

      // Finish the simulation based on pass/fail status
      if (fail) begin
          `FINISH_WITH_FAIL;
      end else begin
          `FINISH_WITH_PASS;
      end
   end

   // This block executes after $finish() has been called.
   final begin
      $display("Simulation time is %t", $time);
      if(error_o === 1) begin
         $display("\033[0;31m    ______                    \033[0m");
         $display("\033[0;31m   / ____/_____________  _____\033[0m");
         $display("\033[0;31m  / __/ / ___/ ___/ __ \\/ ___/\033[0m");
         $display("\033[0;31m / /___/ /  / /  / /_/ / /    \033[0m");
         $display("\033[0;31m/_____/_/  /_/   \\____/_/     \033[0m");
         $display("Simulation Failed");
      end else if (pass_o === 1) begin
         $display("\033[0;32m    ____  ___   __________\033[0m");
         $display("\033[0;32m   / __ \\/   | / ___/ ___/\033[0m");
         $display("\033[0;32m  / /_/ / /| | \\__ \\__ \\ \033[0m");
         $display("\033[0;32m / ____/ ___ |___/ /__/ / \033[0m");
         $display("\033[0;32m/_/   /_/  |_/____/____/  \033[0m");
         $display();
         $display("Simulation Succeeded!");
      end else begin
         $display("   __  ___   ____ __ _   ______ _       ___   __");
         $display("  / / / / | / / //_// | / / __ \\ |     / / | / /");
         $display(" / / / /  |/ / ,<  /  |/ / / / / | /| / /  |/ / ");
         $display("/ /_/ / /|  / /| |/ /|  / /_/ /| |/ |/ / /|  /  ");
         $display("\\____/_/ |_/_/ |_/_/ |_/\\____/ |__/|__/_/ |_/   ");
         $display("Please set error_o or pass_o!");
      end
   end

endmodule
