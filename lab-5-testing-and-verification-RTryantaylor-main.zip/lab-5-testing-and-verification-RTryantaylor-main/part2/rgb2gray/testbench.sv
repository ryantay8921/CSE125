// CORRECT MODULE:
// rgb2gray3.sv

`timescale 1ns/1ps

`define START_TESTBENCH error_o = 0; pass_o = 0; #50;
`define FINISH_WITH_FAIL error_o = 1; pass_o = 0; #50; $finish();
`define FINISH_WITH_PASS pass_o = 1; error_o = 0; #50; $finish();
module testbench
  // You don't usually have ports in a testbench, but we need these to
  // signal to cocotb/gradescope that the testbench has passed, or failed.
  (output logic error_o = 1'bx
  ,output logic pass_o = 1'bx);
  localparam FRAC = 16;
   localparam width_lp = 8;
   logic [width_lp-1:0] red_i, green_i, blue_i;
   logic [width_lp-1:0] gray_o, gray_expected;
   logic [width_lp-1:-FRAC] gray_expected_t;

   // You can use this 
   logic [0:0] error;
   logic [0:0] fail;
   logic [31:0] diff;
   logic [31:0] diff_total;
   logic [31:0] runs;
   logic [31:0] rms;


   rgb2gray #() dut (.red_i(red_i), .green_i(green_i), .blue_i(blue_i), .gray_o());
   assign gray_o = dut.gray_n;
   
    // assign gray_expected = gray_expected_t[width_lp-1:0];


    // assign gray_expected_t = (red_i * 0.2989) + (green_i * 0.5870) + (blue_i * 0.1140);
  logic [width_lp-1:-FRAC] red_conversion, green_conversion, blue_conversion;
  assign red_conversion = {{width_lp{1'b0}},  16'b0100_1100_1000_0100};
  assign green_conversion = {{width_lp{1'b0}},16'b1001_0110_0100_0101};
  assign blue_conversion = {{width_lp{1'b0}}, 16'b0001_1101_0010_1111};

  logic  [width_lp-1:-FRAC] red_mult_i, green_mult_i, blue_mult_i;  //width == width_p + 0 + 0 + |-13| 
  assign red_mult_i = red_i * red_conversion;
  assign green_mult_i = green_i * green_conversion;
  assign blue_mult_i = blue_i * blue_conversion;

  assign gray_expected_t = red_mult_i + blue_mult_i + green_mult_i;
  assign gray_expected = gray_expected_t[width_lp-1:0];

   initial begin
      // Call this to set pass_o and error_o to 0.
      `START_TESTBENCH
      assign fail = 0;
      assign diff = 0;
      assign diff_total = 0;
// /*
      for(red_i =  0; red_i < 'd5; red_i++) begin
        for(green_i = 0; green_i < 'd5; green_i++) begin
            for(blue_i = 0; blue_i < 'd5; blue_i++) begin
                runs++;
                diff = gray_expected - gray_o;
                diff_total = diff_total + (diff * diff);
                rms = $sqrt(diff_total / runs);
                if(rms > 20) begin
                  `FINISH_WITH_FAIL
                end
                $display("RMES = %d", rms); #1;
         end
        end
      end

      for(red_i =  250; red_i < 'd255; red_i++) begin
        for(green_i = 250; green_i < 'd255; green_i++) begin
            for(blue_i = 250; blue_i < 'd255; blue_i++) begin
                runs++;
                diff = gray_expected - gray_o;
                diff_total = diff_total + (diff * diff);
                rms = $sqrt(diff_total / runs);
                if(rms > 20) begin
                  `FINISH_WITH_FAIL
                end
                $display("RMES = %d", rms); #1;
         end
        end
      end

    for(red_i = 120; red_i < 'd125; red_i++) begin
        for(green_i = 120; green_i < 'd125; green_i++) begin
            for(blue_i = 120; blue_i < 'd125; blue_i++) begin
                runs++;
                diff = gray_expected - gray_o;
                diff_total = diff_total + (diff * diff);
                rms = $sqrt(diff_total / runs);
                if(rms > 20) begin
                  `FINISH_WITH_FAIL
                end
                $display("RMES = %d", rms); #1;
         end
        end
      end




      // Use FINISH_WITH_FAIL to end the testbench and cause the FAIL message, and signal fail to cocotb
      // Use FINISH_WITH_PASS to end the testbench and cause the PASS message, and signal pass to cocotb
      // Calling neither will cause the UNKNOWN message, and cause issues in Cocotb.
      if (fail) begin
          `FINISH_WITH_FAIL;
      end else if (~fail) begin
          `FINISH_WITH_PASS;
      end
   end

   // This block executes after $finish() has been called.
   final begin
      $display("Simulation time is %t", $time);
      if(error_o === 1) begin
	 $display("\033[0;31m    ______                    \033[0m");
	 $display("\033[0;31m   / ____/_____________  _____\033[0m");
	 $display("\033[0;31m  / __/ / ___/ ___/ __ \\/ ___/\033[0m");
	 $display("\033[0;31m / /___/ /  / /  / /_/ / /    \033[0m");
	 $display("\033[0;31m/_____/_/  /_/   \\____/_/     \033[0m");
	 $display("Simulation Failed");
     end else if (pass_o === 1) begin
	 $display("\033[0;32m    ____  ___   __________\033[0m");
	 $display("\033[0;32m   / __ \\/   | / ___/ ___/\033[0m");
	 $display("\033[0;32m  / /_/ / /| | \\__ \\\__ \ \033[0m");
	 $display("\033[0;32m / ____/ ___ |___/ /__/ / \033[0m");
	 $display("\033[0;32m/_/   /_/  |_/____/____/  \033[0m");
	 $display();
	 $display("Simulation Succeeded!");
     end else begin
        $display("   __  ___   ____ __ _   ______ _       ___   __");
        $display("  / / / / | / / //_// | / / __ \\ |     / / | / /");
        $display(" / / / /  |/ / ,<  /  |/ / / / / | /| / /  |/ / ");
        $display("/ /_/ / /|  / /| |/ /|  / /_/ /| |/ |/ / /|  /  ");
        $display("\\____/_/ |_/_/ |_/_/ |_/\\____/ |__/|__/_/ |_/   ");
	$display("Please set error_o or pass_o!");
     end
   end

endmodule
