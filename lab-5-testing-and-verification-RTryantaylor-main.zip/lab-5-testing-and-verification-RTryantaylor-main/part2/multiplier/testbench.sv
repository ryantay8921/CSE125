`timescale 1ns/1ps

`define START_TESTBENCH error_o = 0; pass_o = 0; #10;
`define FINISH_WITH_FAIL error_o = 1; pass_o = 0; #10; $finish();
`define FINISH_WITH_PASS pass_o = 1; error_o = 0; #10; $finish();
module testbench
  // You don't usually have ports in a testbench, but we need these to
  // signal to cocotb/gradescope that the testbench has passed, or failed.
  (output logic error_o = 1'bx
  ,output logic pass_o = 1'bx);

  //  localparam width_lp = 8;
  //  logic [width_lp-1:-4] a_i;
  //  logic [width_lp-1:0] b_i;
  //  logic [2 * width_lp - 1  :-4] product_o;
  //  logic [2 * width_lp - 1  :-4] product_o_expected;


     // Fixed-point parameters
   parameter a_int_bits    = 8;
   parameter a_frac_bits   = 2;
   parameter a_bits        = a_int_bits + a_frac_bits; // Total bits for a_i

   parameter b_int_bits    = 7;
   parameter b_frac_bits   = 4;
   parameter b_bits        = b_int_bits + b_frac_bits; // Total bits for b_i

   parameter product_int_bits  = a_int_bits + b_int_bits;
   parameter product_frac_bits = a_frac_bits + b_frac_bits;
   parameter product_bits      = product_int_bits + product_frac_bits; // Total bits for product

   // Signals
   logic signed [a_bits -1 : 0] a_i;
   logic signed [b_bits -1 : 0] b_i;
   logic signed [product_bits -1 : 0] product_o;
   logic signed [product_bits -1 : 0] product_expected;

   // You can use this 
   logic [0:0] error;
   logic [31:0] iter_a,iter_b;
   logic fail;   
   // Write your assertions inside of the DUT modules themselves.
   multiplier #() dut (.a_i(a_i), .b_i(b_i), .product_o(product_o));

   always_comb begin : product
    assign product_expected = a_i * b_i;
   end
   
   initial begin
      // Call this to set pass_o and error_o to 0.
      `START_TESTBENCH
      assign fail = 0;
      #2;
      a_i = 10'sd0;
      b_i = 11'sd0;
      // assign product_expected = a_i * b_i;
      if(product_o !== product_expected) begin  //check 0 * 0
        assign fail = 1;
      end
      #2;

      assign a_i = 10'sd200;
      assign b_i = 11'sd200;
      // assign product_expected = a_i * b_i;
      if(product_o !== product_expected) begin // check + * +
        assign fail = 1;
      end
      #2;

      assign a_i = -10'sd200;
      assign b_i = 11'sd200;
      // assign product_expected = a_i * b_i;
      if(product_o !== product_expected) begin  // check + * -
        assign fail = 1;
      end
      #2;

      assign a_i = -10'sd200;
      assign b_i = -11'sd200;
      // assign product_expected = a_i * b_i;
      if(product_o !== product_expected) begin //check - * -
        assign fail = 1;
      end
      #2;

      assign a_i = 10'sd1023;
      assign b_i = 11'sd2047;
      // assign product_expected = a_i * b_i;
      if(product_o !== product_expected) begin  //check max + * max +
        assign fail = 1;
      end
      #2;

      assign a_i = -10'sd512;
      assign b_i = -11'sd1024;
      // assign product_expected = a_i * b_i;
      if(product_o !== product_expected) begin // check max - * max -
        assign fail = 1;
      end
      #2;
      assign a_i = 10'sd0;
      assign b_i = 11'sd0;

    for (iter_a = 0; iter_a < 6; iter_a++) begin
      for (iter_b = 0; iter_b < 6; iter_b++) begin
        a_i = iter_a;
        b_i = iter_b;
        #2;
        if (product_o !== product_expected) begin
          fail = 1;
        end
      end
    end

    for (iter_a = 0; iter_a < 5; iter_a++) begin
      for (iter_b = 0; iter_b < 5; iter_b++) begin
        a_i = $urandom_range(0, 255);
        b_i = $urandom_range(0, 255);
        #2;
        if (product_o !== product_expected) begin
          fail = 1;
        end
      end
    end




      // Use FINISH_WITH_FAIL to end the testbench and cause the FAIL message, and signal fail to cocotb
      // Use FINISH_WITH_PASS to end the testbench and cause the PASS message, and signal pass to cocotb
      // Calling neither will cause the UNKNOWN message, and cause issues in Cocotb.
      if(fail) begin
         `FINISH_WITH_FAIL;
      end else if(~fail) begin
      `FINISH_WITH_PASS;
   end
end

   // This block executes after $finish() has been called.
   final begin
      $display("Simulation time is %t", $time);
      if(error_o === 1) begin
	 $display("\033[0;31m    ______                    \033[0m");
	 $display("\033[0;31m   / ____/_____________  _____\033[0m");
	 $display("\033[0;31m  / __/ / ___/ ___/ __ \\/ ___/\033[0m");
	 $display("\033[0;31m / /___/ /  / /  / /_/ / /    \033[0m");
	 $display("\033[0;31m/_____/_/  /_/   \\____/_/     \033[0m");
	 $display("Simulation Failed");
     end else if (pass_o === 1) begin
	 $display("\033[0;32m    ____  ___   __________\033[0m");
	 $display("\033[0;32m   / __ \\/   | / ___/ ___/\033[0m");
	 $display("\033[0;32m  / /_/ / /| | \\__ \\\__ \ \033[0m");
	 $display("\033[0;32m / ____/ ___ |___/ /__/ / \033[0m");
	 $display("\033[0;32m/_/   /_/  |_/____/____/  \033[0m");
	 $display();
	 $display("Simulation Succeeded!");
     end else begin
        $display("   __  ___   ____ __ _   ______ _       ___   __");
        $display("  / / / / | / / //_// | / / __ \\ |     / / | / /");
        $display(" / / / /  |/ / ,<  /  |/ / / / / | /| / /  |/ / ");
        $display("/ /_/ / /|  / /| |/ /|  / /_/ /| |/ |/ / /|  /  ");
        $display("\\____/_/ |_/_/ |_/_/ |_/\\____/ |__/|__/_/ |_/   ");
	$display("Please set error_o or pass_o!");
     end
   end

endmodule
