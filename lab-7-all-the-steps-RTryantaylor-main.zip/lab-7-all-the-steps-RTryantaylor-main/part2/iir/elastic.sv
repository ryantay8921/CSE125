module elastic
  #(parameter [31:0] width_p = 8)
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [width_p - 1:0] data_i
  ,input [0:0] valid_i
  ,output [0:0] ready_o 

  ,output [0:0] valid_o 
  ,output [width_p - 1:0] data_o
  ,input [0:0] ready_i
  );

   logic [width_p-1:0] data_transfer;
   logic valid_temp;

   always_ff @(posedge clk_i) begin
      if(reset_i) begin
	      data_transfer <= {width_p{1'b0}};
      end else if(ready_o && valid_i) begin
            data_transfer <= data_i;
      end
   end
   always_ff @(posedge clk_i) begin
      if(reset_i) begin
        valid_temp <= 1'b0;
      end else if(ready_o) begin
         valid_temp <= valid_i;
      end
   end
   assign data_o = data_transfer; 
   assign valid_o = valid_temp;
   assign ready_o = ~valid_o || ready_i;
endmodule
