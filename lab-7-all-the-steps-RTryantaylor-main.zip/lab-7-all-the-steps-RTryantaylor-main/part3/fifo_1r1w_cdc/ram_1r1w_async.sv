`ifndef HEXPATH
  `define HEXPATH ""
`endif
module ram_1r1w_async
  #(parameter [31:0] width_p = 8
  ,parameter [31:0] depth_p = 8
  ,parameter string filename_p = "memory_init_file.bin")
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [0:0] wr_valid_i

  // Fill in the ranges of the busses below
  ,input [width_p-1:0] wr_data_i
  ,input [$clog2(depth_p)-1:0] wr_addr_i

  ,input [$clog2(depth_p)-1:0] rd_addr_i
  ,output [width_p-1: 0] rd_data_o);

  // Memory array
  logic [width_p-1:0] mem_r [depth_p-1:0];

  // Initialize memory
  initial begin
    $display("%m: Initializing memory with depth %0d and width %0d", depth_p, width_p);
    $readmemh({`HEXPATH, filename_p}, mem_r);
    // Debug: dump variables for simulation
    for (int i = 0; i < depth_p; i++)
      $dumpvars(0, mem_r[i]);
  end

    assign rd_data_o = mem_r[rd_addr_i];  // asynchronous read

  // Write behavior
  always_ff @(posedge clk_i) begin
    if (reset_i) begin
    end else if (wr_valid_i) begin
      mem_r[wr_addr_i] <= wr_data_i;
    end
  end

endmodule
