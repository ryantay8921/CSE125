module fifo_1r1w_cdc
 #(parameter [31:0] width_p = 32
  ,parameter [31:0] depth_log2_p = 8
  )
   // To emphasize that the two interfaces are in different clock
   // domains i've annotated the two sides of the fifo with "c" for
   // consumer, and "p" for producer. 

  (input [0:0] cclk_i
  ,input [0:0] creset_i
  ,input [width_p - 1:0] cdata_i
  ,input [0:0] cvalid_i
  ,output [0:0] cready_o 

  ,input [0:0] pclk_i
  ,input [0:0] preset_i
  ,output [0:0] pvalid_o 
  ,output [width_p - 1:0] pdata_o 
  ,input [0:0] pready_i
  );
   
  localparam depth_p = 1 << depth_log2_p;
  logic empty, full, producer_read, consumer_write;

  logic [depth_log2_p:0] producer_rd_ptr, producer_gray_o, producer_wr_ptr, sync1_c2p, sync2_c2p;
  logic [depth_log2_p:0] consumer_wr_ptr, consumer_gray_o, consumer_rd_ptr, sync1_p2c, sync2_p2c;

  assign consumer_write = cready_o && cvalid_i;
  counter #(.width_p(depth_log2_p+1), .reset_val_p({depth_log2_p+1{1'b0}}))
  consumer_counter (.clk_i(cclk_i), .reset_i(creset_i), .up_i(consumer_write), .down_i(1'b0), .count_o(consumer_wr_ptr)); 
  bin2gray #(.width_p(depth_log2_p+1)) 
  consumer_bin2gray (.bin_i(consumer_wr_ptr), .gray_o(consumer_gray_o));
  dff #(.width_p(depth_log2_p+1)) dff_p2c_1 (.clk_i(cclk_i), .reset_i(creset_i), .d_i(producer_gray_o), .en_i(1'b1), .q_o(sync1_p2c));
  dff #(.width_p(depth_log2_p+1)) dff_p2c_2 (.clk_i(cclk_i), .reset_i(creset_i), .d_i(sync1_p2c), .en_i(1'b1), .q_o(sync2_p2c));
  gray2bin #(.width_p(depth_log2_p+1)) 
  consumer_gray2bin (.gray_i(sync2_p2c), .bin_o(consumer_rd_ptr));
  assign full  = (consumer_wr_ptr[depth_log2_p-1:0] == consumer_rd_ptr[depth_log2_p-1:0]) && (consumer_wr_ptr[depth_log2_p] != consumer_rd_ptr[depth_log2_p]);
  assign cready_o = ~full;






  ram_1r1w_async #(.width_p(width_p), .depth_p(depth_p), .filename_p("memory_init_file.bin"))
  ram_x (.clk_i(cclk_i), .reset_i(creset_i),
         .wr_valid_i(consumer_write),
         .wr_data_i(cdata_i), 
         .wr_addr_i(consumer_wr_ptr[depth_log2_p-1:0]),
         .rd_addr_i(producer_rd_ptr[depth_log2_p-1:0]),
         .rd_data_o(pdata_o));







  assign producer_read = pvalid_o && pready_i;
  counter #(.width_p(depth_log2_p+1), .reset_val_p({depth_log2_p+1{1'b0}}))
  producer_counter (.clk_i(pclk_i), .reset_i(preset_i), .up_i(producer_read), .down_i(1'b0), .count_o(producer_rd_ptr)); 
  bin2gray #(.width_p(depth_log2_p+1)) 
  producer_bin2gray (.bin_i(producer_rd_ptr), .gray_o(producer_gray_o));
  dff #(.width_p(depth_log2_p+1)) dff_c2p_1 (.clk_i(pclk_i), .reset_i(preset_i), .d_i(consumer_gray_o), .en_i(1'b1), .q_o(sync1_c2p));
  dff #(.width_p(depth_log2_p+1)) dff_c2p_2 (.clk_i(pclk_i), .reset_i(preset_i), .d_i(sync1_c2p), .en_i(1'b1), .q_o(sync2_c2p));
  gray2bin #(.width_p(depth_log2_p+1)) 
  producer_gray2bin (.gray_i(sync2_c2p), .bin_o(producer_wr_ptr));
  assign empty = (producer_wr_ptr[depth_log2_p-1:0] == producer_rd_ptr[depth_log2_p-1:0]) && (producer_wr_ptr[depth_log2_p] == producer_rd_ptr[depth_log2_p]);
  assign pvalid_o = ~empty;


endmodule
