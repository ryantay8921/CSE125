module fifo_1r1w_cdc
 #(parameter [31:0] width_p = 32
  ,parameter [31:0] depth_log2_p = 8
  )
   // To emphasize that the two interfaces are in different clock
   // domains i've annotated the two sides of the fifo with "c" for
   // consumer, and "p" for producer. 

  (input [0:0] cclk_i
  ,input [0:0] creset_i
  ,input [width_p - 1:0] cdata_i
  ,input [0:0] cvalid_i
  ,output [0:0] cready_o 

  ,input [0:0] pclk_i
  ,input [0:0] preset_i
  ,output [0:0] pvalid_o 
  ,output [width_p - 1:0] pdata_o 
  ,input [0:0] pready_i
  );
   
  localparam depth_p = 1 << depth_log2_p;
  logic empty, full, producer_read, consumer_write;

  logic [depth_log2_p:0] producer_rd_ptr_q, producer_rd_ptr_d, producer_gray_o, producer_wr_ptr, sync1_c2p, sync2_c2p, sync3_c2p;
  logic [depth_log2_p:0] consumer_wr_ptr_q, consumer_wr_ptr_d, consumer_gray_o, consumer_rd_ptr, sync1_p2c, sync2_p2c, sync3_p2c;

  assign consumer_write = cready_o && cvalid_i;
  always_ff @(posedge cclk_i) begin
    if (creset_i) begin
      consumer_wr_ptr_q <= '0;
    end else begin
      consumer_wr_ptr_q <= consumer_wr_ptr_d;
    end
  end
  always_comb begin
    consumer_wr_ptr_d = consumer_wr_ptr_q;
    if(consumer_write && producer_read) begin
        consumer_wr_ptr_d = consumer_wr_ptr_d+1;
    end else if (consumer_write && ~producer_read) begin
        consumer_wr_ptr_d = consumer_wr_ptr_d+1;
    end else if (~consumer_write && producer_read) begin
        consumer_wr_ptr_d = consumer_wr_ptr_d;
    end
  end
  bin2gray #(.width_p(depth_log2_p+1)) 
  consumer_bin2gray (.bin_i(consumer_wr_ptr_q), .gray_o(consumer_gray_o));
  dff #(.width_p(depth_log2_p+1)) dff_c2p_1 (.clk_i(cclk_i), .reset_i(creset_i), .d_i(consumer_gray_o), .en_i(1'b1), .q_o(sync1_c2p));



  dff #(.width_p(depth_log2_p+1)) dff_p2c_2 (.clk_i(cclk_i), .reset_i(creset_i), .d_i(sync1_p2c),       .en_i(1'b1), .q_o(sync2_p2c));
  dff #(.width_p(depth_log2_p+1)) dff_p2c_3 (.clk_i(cclk_i), .reset_i(creset_i), .d_i(sync2_p2c),       .en_i(1'b1), .q_o(sync3_p2c));
  gray2bin #(.width_p(depth_log2_p+1)) 
  consumer_gray2bin (.gray_i(sync3_p2c), .bin_o(consumer_rd_ptr));
  assign full  = (consumer_wr_ptr_q[depth_log2_p-1:0] == consumer_rd_ptr[depth_log2_p-1:0]) && (consumer_wr_ptr_q[depth_log2_p] != consumer_rd_ptr[depth_log2_p]);
  assign cready_o = ~full;






  ram_1r1w_sync #(.width_p(width_p), .depth_p(depth_p), .filename_p("memory_init_file.bin"))
  ram_x (.c_clk_i(cclk_i), .p_clk_i(pclk_i),
         .reset_i(preset_i),
         .wr_valid_i(consumer_write),
         .wr_data_i(cdata_i), 
         .wr_addr_i(consumer_wr_ptr_q[depth_log2_p-1:0]),
         .rd_valid_i(1'b1),
         .rd_addr_i(producer_rd_ptr_d[depth_log2_p-1:0]),
         .rd_data_o(pdata_o));







  assign producer_read = pvalid_o && pready_i;
  always_ff @(posedge pclk_i) begin
    if (preset_i) begin
      producer_rd_ptr_q <= '0;
    end else begin
      producer_rd_ptr_q <= producer_rd_ptr_d;
    end
  end
  always_comb begin
    producer_rd_ptr_d = producer_rd_ptr_q;
    if(consumer_write && producer_read) begin
        producer_rd_ptr_d = producer_rd_ptr_d+1;
    end else if (consumer_write && ~producer_read) begin
        producer_rd_ptr_d = producer_rd_ptr_d;
    end else if (~consumer_write && producer_read) begin
        producer_rd_ptr_d = producer_rd_ptr_d+1;
    end
  end
  bin2gray #(.width_p(depth_log2_p+1)) 
  producer_bin2gray (.bin_i(producer_rd_ptr_q), .gray_o(producer_gray_o));
  dff #(.width_p(depth_log2_p+1)) dff_p2c_1 (.clk_i(pclk_i), .reset_i(preset_i), .d_i(producer_gray_o), .en_i(1'b1), .q_o(sync1_p2c));



  dff #(.width_p(depth_log2_p+1)) dff_c2p_2 (.clk_i(pclk_i), .reset_i(preset_i), .d_i(sync1_c2p),       .en_i(1'b1), .q_o(sync2_c2p));
  dff #(.width_p(depth_log2_p+1)) dff_c2p_3 (.clk_i(pclk_i), .reset_i(preset_i), .d_i(sync2_c2p),       .en_i(1'b1), .q_o(sync3_c2p));
  gray2bin #(.width_p(depth_log2_p+1)) 
  producer_gray2bin (.gray_i(sync3_c2p), .bin_o(producer_wr_ptr));
  assign empty = (producer_wr_ptr[depth_log2_p-1:0] == producer_rd_ptr_q[depth_log2_p-1:0]) && (producer_wr_ptr[depth_log2_p] == producer_rd_ptr_q[depth_log2_p]);
  assign pvalid_o = ~empty;


endmodule
