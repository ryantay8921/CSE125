module gray2bin
  #(parameter width_p = 5)
   (input [width_p - 1 : 0] gray_i
    ,output [width_p - 1 : 0] bin_o);

    // bin[5] = g5;
    // bin[4] = g5 ^ g4;
    // bin[3] = g5 ^ g4 ^ g3;
    // bin[2] = g5 ^ g4 ^ g3 ^ g2;
    // bin[1] = g5 ^ g4 ^ g3 ^ g2 ^ g1;
    // bin[0] = g5 ^ g4 ^ g3 ^ g2 ^ g1 ^ g0;

    // bin[5] = g5;
    // bin[4] = bin[5] ^ g4;
    // bin[3] = bin[4] ^ g3;
    // bin[2] = bin[3] ^ g2;
    // bin[1] = bin[2] ^ g1;
    // bin[0] = bin[1] ^ g0;

    // assign bin_o[width_p-1] = gray_i[width_p-1];  //covers most significant bit
    // genvar i;
    // generate
    // for (i = width_p-2; i < 0 ; i--) begin
    //   assign bin_o[i] = bin_o[i+1] ^ gray_i[i];
    // end
    // endgenerate


    assign bin_o[width_p-1] = gray_i[width_p-1];  //covers most significant bit
    genvar i;
    generate
    for (i = width_p-2; i >= 0 ; i--) begin
      assign bin_o[i] = ^gray_i[width_p-1:i];
    end
    endgenerate


endmodule
