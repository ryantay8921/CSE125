module fifo_1r1w
  #(parameter [31:0] width_p = 8
   // Note: Not depth_p! depth_p should be 1<<depth_log2_p
   ,parameter [31:0] depth_log2_p = 8
   )
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [width_p - 1:0] data_i
  ,input [0:0] valid_i
  ,output [0:0] ready_o 

  ,output [0:0] valid_o 
  ,output [width_p - 1:0] data_o 
  ,input [0:0] ready_i
  );

  localparam depth_p = 1 << depth_log2_p;
  logic [depth_log2_p:0] rd_address, wr_address;
  logic up_read, up_write, full, empty;

  ram_1r1w_async #(.width_p(width_p), .depth_p(depth_p), .filename_p("FIFO.hex"))
  ram_x (.clk_i(clk_i), .reset_i(reset_i),
         .wr_valid_i(valid_i && ready_o),
         .wr_data_i(data_i), 
         .wr_addr_i(wr_address[depth_log2_p-1:0]),
         .rd_addr_i(rd_address[depth_log2_p-1:0]),
         .rd_data_o(data_o));

  counter #(.width_p(depth_log2_p+1), .reset_val_p({depth_log2_p+1{1'b0}}))
  counter_read (.clk_i(clk_i), .reset_i(reset_i), .up_i(up_read), .down_i(1'b0), .count_o(rd_address)); 
  
  counter #(.width_p(depth_log2_p+1), .reset_val_p({depth_log2_p+1{1'b0}}))
  counter_write (.clk_i(clk_i), .reset_i(reset_i), .up_i(up_write), .down_i(1'b0), .count_o(wr_address)); 


  assign empty = (wr_address[depth_log2_p-1:0] == rd_address[depth_log2_p-1:0]) && (wr_address[depth_log2_p] == rd_address[depth_log2_p]);
  assign full  = (wr_address[depth_log2_p-1:0] == rd_address[depth_log2_p-1:0]) && (wr_address[depth_log2_p] != rd_address[depth_log2_p]);
  assign up_read = valid_o && ready_i && ~empty;
  assign up_write = valid_i && ready_o && ~full;
  assign valid_o = ~empty;
  assign ready_o = ~full;


endmodule
