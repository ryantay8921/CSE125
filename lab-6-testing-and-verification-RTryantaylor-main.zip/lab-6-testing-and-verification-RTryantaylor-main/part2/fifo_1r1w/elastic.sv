module elastic_sync
  #(parameter [31:0] width_p = 8
  /* verilator lint_off WIDTHTRUNC */
   ,parameter [0:0] datapath_gate_p = 0
   ,parameter [0:0] datapath_reset_p = 0
   /* verilator lint_on WIDTHTRUNC */
   )
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [width_p - 1:0] data_i
  ,input [0:0] valid_i
  ,output [0:0] ready_o 

  ,output [0:0] valid_o 
  ,output [width_p - 1:0] data_o 
  ,input [0:0] ready_i
  );

   logic [width_p-1:0] data_transfer;
   logic valid_temp;

   always_ff @(posedge clk_i) begin
      if(reset_i && datapath_reset_p) begin
	      data_transfer <= {width_p{1'b0}};
      end
      if(reset_i) begin
        valid_temp <= 1'b0;
      end
      else begin
        if(ready_o && valid_i && datapath_gate_p) begin
            data_transfer <= data_i;
        end else if(ready_o) begin
          data_transfer <= data_i;
        end
        if(ready_o) begin
          valid_temp <= ready_o && valid_i;
        end
      end 
   end
   
   assign data_o = data_transfer; 
   assign valid_o = valid_temp;
  //  assign ready_o = ~valid_o || ready_i;
   assign ready_o = ~valid_o || (valid_o && ready_i);


endmodule
