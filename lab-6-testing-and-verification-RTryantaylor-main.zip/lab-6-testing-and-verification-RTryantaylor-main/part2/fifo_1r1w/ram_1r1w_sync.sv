`ifndef BINPATH
 `define BINPATH ""
`endif
module ram_1r1w_sync
  #(parameter [31:0] width_p = 32
  ,parameter [31:0] depth_p = 8
  /* verilator lint_off UNUSEDPARAM */
  ,parameter string filename_p = "memory_init_file.bin")
  /* verilator lint_on UNUSEDPARAM */
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [0:0] wr_valid_i
  ,input [width_p-1:0] wr_data_i
  ,input [$clog2(depth_p) - 1 : 0] wr_addr_i

  ,input [0:0] rd_valid_i
  ,input [$clog2(depth_p) - 1 : 0] rd_addr_i
  ,output [width_p-1:0] rd_data_o);

   logic [width_p-1:0] mem_r [depth_p-1:0];

   
   initial begin
      // Display depth and width (You will need to match these in your init file)
      $display("%m: depth_p is %d, width_p is %d", depth_p, width_p);
 //     $readmemb({BINPATH, filename_p}, mem_r);
      // wire [bar:0] foo [baz:0];
      // In order to get the memory contents in iverilog you need to run this for loop during initialization:
      for (int i = 0; i < depth_p; i++) begin
        mem_r[i] = '0;
        $dumpvars(0, mem_r[i]);
      end
    end

   logic [width_p-1:0] old_data;
   logic [$clog2(depth_p)-1:0] rd_addr_q ;

    always_ff @(posedge clk_i)
      if(reset_i) begin
        rd_addr_q  <= '0;
        old_data <= '0;
      end else begin
          if(rd_valid_i) begin
             rd_addr_q  <= rd_addr_i;
          end
          if(wr_valid_i) begin
	           old_data <= mem_r[wr_addr_i];
             mem_r[wr_addr_i] <= wr_data_i;
          end
        end
    assign rd_data_o = (wr_valid_i && (wr_addr_i == rd_addr_q )) ? old_data : mem_r[rd_addr_q];

endmodule
