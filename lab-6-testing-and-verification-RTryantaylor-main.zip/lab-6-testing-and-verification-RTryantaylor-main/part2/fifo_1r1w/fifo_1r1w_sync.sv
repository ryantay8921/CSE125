module fifo_1r1w_sync
  #(parameter [31:0] width_p = 32
   ,parameter [31:0] depth_log2_p = 8
   )
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [width_p - 1:0] data_i
  ,input [0:0] valid_i
  ,output [0:0] ready_o 

  ,output [0:0] valid_o 
  ,output [width_p - 1:0] data_o 
  ,input [0:0] ready_i
  );

  localparam depth_p = 1 << depth_log2_p;

  logic full, empty, valid_read, valid_write, wr_last;
  logic [depth_log2_p-1:0] wr_address_q, wr_address_d, wr_address_last;
  logic [depth_log2_p-1:0] rd_address_q, rd_address_d;
  logic [depth_log2_p:0] count_q, count_d;
  logic [width_p-1:0] data_rd, data_pipe, hzd;

  ram_1r1w_sync #(.width_p(width_p), .depth_p(depth_p)) 
  ram_inst(
    .clk_i(clk_i),
    .reset_i(reset_i),
    .wr_valid_i(valid_write),
    .wr_data_i(data_i),
    .wr_addr_i(wr_address_q),
    .rd_valid_i(valid_read),
    .rd_addr_i(rd_address_d),
    .rd_data_o(data_rd)
  );
  
  elastic_sync #() 
  elastic_inst(
    .clk_i(clk_i),
    .reset_i(reset_i),
    .data_i(data_i),
    .valid_i(valid_i),
    .ready_o(),
    .valid_o(),
    .ready_i(ready_i),
    .data_o(data_pipe)
  );

  assign full = (count_q == depth_p);
  assign empty = (count_q == 0);
  assign valid_read = valid_o && ready_i;
  assign valid_write = valid_i && ready_o;
  assign hzd = {width_p{(wr_address_last == rd_address_q) & wr_last}};

  always_ff @(posedge clk_i) begin
    if (reset_i) begin
      count_q <= '0;
      wr_address_q <= '0;
      rd_address_q <= '0;
      wr_address_last <= '0;
      wr_last <= '0;
    end else begin
      count_q <= count_d;
      wr_address_q <= wr_address_d;
      rd_address_q <= rd_address_d;
      wr_address_last <= wr_address_q;
      wr_last <= valid_i & ready_o;
    end
  end

  always_comb begin
    count_d = count_q;
    wr_address_d = wr_address_q;
    rd_address_d = rd_address_q;
    if(valid_write && valid_read) begin
        wr_address_d = wr_address_d+1;
        rd_address_d = rd_address_d+1;
    end else if (valid_write && ~valid_read) begin
        wr_address_d = wr_address_d+1;
        count_d = count_d+1;
    end else if (~valid_write && valid_read) begin
        rd_address_d = rd_address_d+1;
        count_d = count_q-1;
    end
  end

  assign ready_o = (count_q != depth_p);
  assign valid_o = (count_q != 0);
  assign data_o = (data_rd & ~hzd) | (data_pipe & hzd);

endmodule
