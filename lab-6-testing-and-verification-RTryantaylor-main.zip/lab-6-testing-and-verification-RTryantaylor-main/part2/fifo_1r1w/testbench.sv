`timescale 1ns/1ps

// 1 : ready_o goes low at (count_q == depth_p(@128) instead of at 256)
// 2 : ready_o follows valid_i
// 3 : valid_0 is low when count_q != 0
// 4 : moves lsb to msb
// 5 is correct


`define START_TESTBENCH error_o = 0; pass_o = 0; #10;
`define FINISH_WITH_FAIL error_o = 1; pass_o = 0; #10; $finish();
`define FINISH_WITH_PASS pass_o = 1; error_o = 0; #10; $finish();
module testbench
  // You don't usually have ports in a testbench, but we need these to
  // signal to cocotb/gradescope that the testbench has passed, or failed.
  (output logic error_o = 1'bx
  ,output logic pass_o = 1'bx);

   // You can use this 
   logic [0:0] error;
   
   wire        clk_i;
   wire        reset_i;

   logic valid_i ,ready_o, valid_o, ready_i;
   logic valid_o_expected, ready_o_expected;
   logic [31:0] data_i, data_o, data_o_expected, delay, fail;

   logic [31:0] itervar;
   nonsynth_clock_gen #(.cycle_time_p(10)) cg (.clk_o(clk_i));
   nonsynth_reset_gen #(.reset_cycles_lo_p(1) ,.reset_cycles_hi_p(10)) rg (.clk_i(clk_i) ,.async_reset_o(reset_i));

   fifo_1r1w_sync #()
   dut_sync (.clk_i(clk_i), .reset_i(reset_i),
        .data_i(data_i), .valid_i(valid_i), .ready_o(ready_o_expected),
        .data_o(data_o_expected), .valid_o(valid_o_expected), .ready_i(ready_i));

  fifo_1r1w #() dut (.clk_i(clk_i), .reset_i(reset_i),
                     .data_i(data_i), .valid_i(valid_i), .ready_o(ready_o),
                     .data_o(data_o), .valid_o(valid_o), .ready_i(ready_i));


  always_ff@(posedge clk_i) begin
      if(~reset_i && valid_o_expected && ready_i) begin  
        if(data_o !== data_o_expected) begin
          fail++;
          $display("FAILED_data: data_o_expected: %d, data_o: %d, fail_state: %d", data_o_expected, data_o, fail);
        end
      end
      if(ready_o !== ready_o_expected) begin
        fail++;
        $display("FAILED_ready: ready_o_expected: %d, ready_o: %d", ready_o_expected, ready_o);
      end
      if(valid_o !== valid_o_expected) begin
        fail++;
        $display("FAILED_valid: valid_o_expected: %d, valid_o: %d", valid_o_expected, valid_o);
      end 
    end

   initial begin
      // Call this to set pass_o and error_o to 0.
      `START_TESTBENCH
      fail = 0;
      valid_i = 1;
      ready_i = 0;
      data_i = 0;
      @(negedge reset_i);
      

      for(itervar = 0; itervar < 'd10; itervar++) begin
         ready_i = itervar[0];
         valid_i = itervar[1];
         @(negedge clk_i);
         for(delay = 0; delay < 'd5; delay++) begin
            data_i = 1;
            @(negedge clk_i);
         end
      end

      @(negedge clk_i);
      valid_i = '1;
      ready_i = '0;
      @(negedge clk_i);
      for(itervar = 0; itervar < 'd128; itervar++) begin
        data_i = itervar;
        @(negedge clk_i);
      end

      if(fail >= 'd1) begin
        `FINISH_WITH_FAIL;
      end else begin
        `FINISH_WITH_PASS;
      end
   end

   // This block executes after $finish() has been called.
   final begin
      $display("Simulation time is %t", $time);
      if(error_o === 1) begin
	 $display("\033[0;31m    ______                    \033[0m");
	 $display("\033[0;31m   / ____/_____________  _____\033[0m");
	 $display("\033[0;31m  / __/ / ___/ ___/ __ \\/ ___/\033[0m");
	 $display("\033[0;31m / /___/ /  / /  / /_/ / /    \033[0m");
	 $display("\033[0;31m/_____/_/  /_/   \\____/_/     \033[0m");
	 $display("Simulation Failed");
     end else if (pass_o === 1) begin
	 $display("\033[0;32m    ____  ___   __________\033[0m");
	 $display("\033[0;32m   / __ \\/   | / ___/ ___/\033[0m");
	 $display("\033[0;32m  / /_/ / /| | \\__ \\\__ \ \033[0m");
	 $display("\033[0;32m / ____/ ___ |___/ /__/ / \033[0m");
	 $display("\033[0;32m/_/   /_/  |_/____/____/  \033[0m");
	 $display();
	 $display("Simulation Succeeded!");
     end else begin
        $display("   __  ___   ____ __ _   ______ _       ___   __");
        $display("  / / / / | / / //_// | / / __ \\ |     / / | / /");
        $display(" / / / /  |/ / ,<  /  |/ / / / / | /| / /  |/ / ");
        $display("/ /_/ / /|  / /| |/ /|  / /_/ /| |/ |/ / /|  /  ");
        $display("\\____/_/ |_/_/ |_/_/ |_/\\____/ |__/|__/_/ |_/   ");
	$display("Please set error_o or pass_o!");
     end
   end

endmodule
