`ifndef BINPATH
 `define BINPATH ""

// `define read
`define write

`endif
module ram_1w1r_sync_expected
  #(parameter [31:0] width_p = 8
  ,parameter [31:0] depth_p = 512
  /* verilator lint_off UNUSEDPARAM */
  ,parameter string filename_p = "memory_init_file.bin")
  /* verilator lint_on UNUSEDPARAM */
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [0:0] wr_valid_i
  ,input [width_p-1:0] wr_data_i
  ,input [$clog2(depth_p) - 1 : 0] wr_addr_i

  ,input [0:0] rd_valid_i
  ,input [$clog2(depth_p) - 1 : 0] rd_addr_i
  ,output [width_p-1:0] rd_data_o);

   logic [width_p-1:0] mem_r [depth_p-1:0];

   
   initial begin
      // Display depth and width (You will need to match these in your init file)
      $display("%m: depth_p is %d, width_p is %d", depth_p, width_p);
 //     $readmemb({BINPATH, filename_p}, mem_r);
      // wire [bar:0] foo [baz:0];
      // In order to get the memory contents in iverilog you need to run this for loop during initialization:
      for (int i = 0; i < depth_p; i++) begin
        mem_r[i] = '0;
        $dumpvars(0, mem_r[i]);
      end
    end


`ifdef write
   // write first
   logic [width_p-1:0] rd_data_q;
   assign rd_data_o = rd_data_q;                                                                                                                                                                  
                                                                                                                                                                          
   always @(posedge clk_i) begin                                                                                                                                          
      if(reset_i) begin                                                                                                                                                   
         rd_data_q <= '0;
      end else begin
         if(wr_valid_i && (rd_addr_i == wr_addr_i)) begin
            rd_data_q <= wr_data_i;
            mem_r[wr_addr_i] <= wr_data_i;  
         end else if(rd_valid_i && wr_valid_i) begin
            mem_r[wr_addr_i] <= wr_data_i;  
            rd_data_q <= '0;   
         end else if(rd_valid_i && ~wr_valid_i) begin                                                                                                                                       
            rd_data_q <= mem_r[rd_addr_i];                                                                                                                                     
         end else if(wr_valid_i && ~rd_valid_i) begin                                                                                                                                       
            mem_r[wr_addr_i] <= wr_data_i;     
         end   
      end                                                                                                                                  
   end 
`endif


`ifdef read   //read first
   logic [width_p-1:0] rd_data_q ;

   always @(posedge clk_i) begin                                                                                                                                          
      if(reset_i) begin                                                                                                                                                   
         ;                                                                                                                                                                
      end else if(wr_valid_i) begin                                                                                                                                       
         mem_r[wr_addr_i] <= wr_data_i;                                                                                                                                     
      end                                                                                                                                                                 
   end                                                                                                                                                                                                                                                                                                                        
   always @(posedge clk_i) begin                                                                                                                                          
      if(reset_i) begin                                                                                                                                                   
         rd_data_q <= '0;                                                                                                                                                 
      end else if(rd_valid_i) begin                                                                                                                                       
         rd_data_q <= mem_r[rd_addr_i];                                                                                                                                     
      end else                                                                                                                                       
         rd_data_q <= '0;                                                                                                                                                             
   end                                                                                                                                                                    

   assign rd_data_o = rd_data_q;
`endif

endmodule
