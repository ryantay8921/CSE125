`timescale 1ns/1ps
// 1 : correct
// 2 : data is inversed, 00-> FF
// 3 : read priority
// 4 : breaks on reset, reset clears all memory, this doesn't syth to a ram.
// 5 : rd is asynchronous

`define test_simple_case  //fails 2
`define test_write_priority  // fails 3
`define test_read_write_diff
`define test_edge  // fails 2
`define test_loop 
`define test_reset  //fails 4


// Macros for signaling pass/fail
`define START_TESTBENCH error_o = 0; pass_o = 0; #10;
`define FINISH_WITH_FAIL error_o = 1; pass_o = 0; #10; $finish();
`define FINISH_WITH_PASS pass_o = 1; error_o = 0; #10; $finish();

module testbench
  (
    output logic error_o = 1'bx, // Output to signal error
    output logic pass_o = 1'bx   // Output to signal pass
  );
   localparam width_p = 8;
   localparam depth_p = 512;

  logic clk_i;
  logic reset_i, reset_2; 
  logic wr_valid_i;
  logic [7:0] wr_data_i;
  logic [8:0] wr_addr_i;
  logic rd_valid_i;
  logic [8:0] rd_addr_i;
  logic [7:0] rd_data_o;
  logic [7:0] rd_data_o_expected;
  logic [31:0] fail;

  nonsynth_clock_gen #(.cycle_time_p(10)) cg (.clk_o(clk_i));
  nonsynth_reset_gen #(.reset_cycles_lo_p(1), .reset_cycles_hi_p(10)) rg (.clk_i(clk_i),.async_reset_o(reset_i));

  ram_1w1r_sync #() dut (.clk_i(clk_i), .reset_i(reset_i  || reset_2),
    .wr_valid_i(wr_valid_i), .wr_data_i(wr_data_i), .wr_addr_i(wr_addr_i),
    .rd_valid_i(rd_valid_i), .rd_addr_i(rd_addr_i), .rd_data_o(rd_data_o));
  ram_1w1r_sync_expected #(.width_p(8), .depth_p(512)) ram_1w1r_sync_expected (.clk_i(clk_i), .reset_i(reset_i || reset_2),
    .wr_valid_i(wr_valid_i), .wr_data_i(wr_data_i), .wr_addr_i(wr_addr_i),
    .rd_valid_i(rd_valid_i), .rd_addr_i(rd_addr_i), .rd_data_o(rd_data_o_expected));

always_ff @( posedge clk_i ) begin : blockName
  if (!reset_i && (rd_data_o != rd_data_o_expected)) begin
    fail++;
    $display("FAILED: Expected: %h, Got: %h at time %t", rd_data_o_expected, rd_data_o, $time);
  end else begin
    $display("PASSED: Data: %h at time %t", rd_data_o, $time);
  end
end

  initial begin
    `START_TESTBENCH
    fail = 0;
    reset_2 = 0;
    wr_valid_i = 0;
    wr_data_i = 0;
    wr_addr_i = 0;
    rd_valid_i = 0;
    rd_addr_i = 0;

    @(negedge reset_i);
    repeat (2) @(posedge clk_i);

`ifdef test_simple_case
    // === Test 1: Basic Write and Read ===
    $display("\n=== Test 1: Basic Write and Read ===");
    @(negedge clk_i);
    wr_valid_i = 1;
    wr_addr_i = 9'd10;
    wr_data_i = 8'hAA;
    @(negedge clk_i);
    wr_valid_i = 0;

    // Read from address 10 on negedge clk_i
    @(negedge clk_i);
    rd_valid_i = 1;
    rd_addr_i = 9'd10;
    @(negedge clk_i); // Perform read
    rd_valid_i = 0;
    @(negedge clk_i); // Wait for data to propagate
`endif

`ifdef test_write_priority
    // === Test 2: Write Priority ===
    $display("\n=== Test 2: Write Priority ===");

    // Assuming initial data at address 20 is 0x00
    // Initiate simultaneous write and read on negedge clk_i
    @(negedge clk_i);
    wr_valid_i = 1;
    wr_addr_i = 9'd20;
    wr_data_i = 8'h55;
    rd_valid_i = 1;
    rd_addr_i = 9'd20;
    @(negedge clk_i); // Both write and read occur
    wr_valid_i = 0;
    rd_valid_i = 0;
    @(negedge clk_i); // Wait for read data to propagate

    @(negedge clk_i);
    rd_valid_i = 1;
    rd_addr_i = 9'd20;
    @(negedge clk_i); // Perform read
    rd_valid_i = 0;
    @(negedge clk_i); // Wait for data to propagate
`endif

`ifdef test_read_write_diff
   // === Test: Simultaneous Read and Write to Different Addresses ===
    $display("\n=== Test: Simultaneous Read and Write to Different Addresses ===");

    // Write to address 200 while reading from address 201 on negedge clk_i
    @(negedge clk_i);
    wr_valid_i = 1;
    wr_addr_i = 9'd200;
    wr_data_i = 8'h77;
    rd_valid_i = 1;
    rd_addr_i = 9'd201;
    @(negedge clk_i); // Both write and read occur
    wr_valid_i = 0;
    rd_valid_i = 0;
    @(negedge clk_i); // Wait for read data to propagate

    // Read from address 200 to verify the write
    @(negedge clk_i);
    rd_valid_i = 1;
    rd_addr_i = 9'd200;
    @(negedge clk_i); // Perform read
    rd_valid_i = 0;
    @(negedge clk_i); // Wait for data
`endif

`ifdef test_edge
    // === Test 3: Edge Address Write and Read ===
    $display("\n=== Test 3: Edge Address Write and Read ===");

    // Write to first address (0) on negedge clk_i
    @(negedge clk_i);
    wr_valid_i = 1;
    wr_addr_i = 9'd0;
    wr_data_i = 8'hFF;
    @(negedge clk_i); // Perform write
    wr_valid_i = 0;

    // Write to last address (511) on negedge clk_i
    @(negedge clk_i);
    wr_valid_i = 1;
    wr_addr_i = 9'd511;
    wr_data_i = 8'h00;
    @(negedge clk_i); // Perform write
    wr_valid_i = 0;

    // Read from first address (0) on negedge clk_i
    @(negedge clk_i);
    rd_valid_i = 1;
    rd_addr_i = 9'd0;
    @(negedge clk_i); // Perform read
    rd_valid_i = 0;
    @(negedge clk_i); // Wait for data

    @(negedge clk_i);
    rd_valid_i = 1;
    rd_addr_i = 9'd511;
    @(negedge clk_i); // Perform read
    rd_valid_i = 0;
    @(negedge clk_i); // Wait for data
`endif

`ifdef test_loop
      $display("\n=== Test Loop: Write Priority ===");
      for( int intrvar = 0; intrvar < 'd255; intrvar++)begin
         @(negedge clk_i);
         wr_data_i = intrvar[width_p-1:0];
         wr_addr_i = intrvar[$clog2(depth_p) - 1 : 0];
      end
      @(negedge clk_i);
      wr_valid_i = '0;
      rd_valid_i = '1;
      for( int intrvar = 0; intrvar < 'd255; intrvar++)begin
          @(negedge clk_i);
          rd_addr_i = intrvar[$clog2(depth_p) - 1 : 0];
      end
      @(negedge clk_i);
      rd_valid_i = '1;
      wr_valid_i = '1;
      for(int intrvar = 0; intrvar < 'd255; intrvar++)begin
          @(negedge clk_i);
          rd_addr_i = intrvar[$clog2(depth_p) - 1 : 0];
          wr_addr_i = intrvar[$clog2(depth_p) - 1 : 0];
          wr_data_i = intrvar[width_p-1:0];
      end
      rd_valid_i = '0;
      wr_valid_i = '0;
`endif

`ifdef test_reset
// === Test 4: Reset Behavior ===
    $display("\n=== Test 4: Reset Behavior ===");

    // Write to address 100 with data 0xCC before reset
    @(negedge clk_i);

    wr_valid_i = 1;
    wr_addr_i = 9'd100;
    wr_data_i = 8'hCC;
    @(negedge clk_i); // Perform write
    wr_valid_i = 0;
    @(negedge clk_i);
    reset_2 = 1;
    @(negedge clk_i);
    reset_2 = 0;
    @(negedge clk_i);
    @(negedge clk_i);
    rd_valid_i = 1;
    rd_addr_i = 9'd100;
    @(negedge clk_i); // Perform read
    rd_valid_i = 0;
    @(negedge clk_i); // Wait for data to propagate
`endif

    if (fail >= 1) begin
      `FINISH_WITH_FAIL
    end else begin
      `FINISH_WITH_PASS
    end
  end


  final begin
    $display("\nSimulation time is %t ns", $time);
    if (error_o === 1) begin
      // Failed simulation message with colored text
      $display("\033[0;31m    ______                    \033[0m");
      $display("\033[0;31m   / ____/_____________  _____\033[0m");
      $display("\033[0;31m  / __/ / ___/ ___/ __ \\/ ___/\033[0m");
      $display("\033[0;31m / /___/ /  / /  / /_/ / /    \033[0m");
      $display("\033[0;31m/_____/_/  /_/   \\____/_/     \033[0m");
      $display("Simulation Failed");
    end else if (pass_o === 1) begin
      // Passed simulation message with colored text
      $display("\033[0;32m    ____  ___   __________\033[0m");
      $display("\033[0;32m   / __ \\/   | / ___/ ___/\033[0m");
      $display("\033[0;32m  / /_/ / /| | \\__ \\\__ \ \033[0m");
      $display("\033[0;32m / ____/ ___ |___/ /__/ / \033[0m");
      $display("\033[0;32m/_/   /_/  |_/____/____/  \033[0m");
      $display();
      $display("Simulation Succeeded!");
    end else begin
      // Fallback message if neither pass nor fail is set
      $display("   __  ___   ____ __ _   ______ _       ___   __");
      $display("  / / / / | / / //_// | / / __ \\ |     / / | / /");
      $display(" / / / /  |/ / ,<  /  |/ / / / / | /| / /  |/ / ");
      $display("/ /_/ / /|  / /| |/ /|  / /_/ /| |/ |/ / /|  /  ");
      $display("\\____/_/ |_/_/ |_/_/ |_/\\____/ |__/|__/_/ |_/   ");
      $display("Please set error_o or pass_o!");
    end
  end

endmodule
