`timescale 1ns/1ps

//counter1: negedge clk not posedge
//counter2: doesnt count up or down, ~reset
//counter3: up_i(actually counts down), and down_i(actually counts up)
//counter4: CORRECT
//counter5: async reset

`define START_TESTBENCH error_o = 0; pass_o = 0; #10;
`define FINISH_WITH_FAIL error_o = 1; pass_o = 0; #10; $finish();
`define FINISH_WITH_PASS pass_o = 1; error_o = 0; #10; $finish();
module testbench
  // You don't usually have ports in a testbench, but we need these to
  // signal to cocotb/gradescope that the testbench has passed, or failed.
  (output logic error_o = 1'bx
  ,output logic pass_o = 1'bx);

   // You can use this 
   logic [0:0] error;
   
   wire        clk_i;
   wire        reset_i;
   logic fail, up_i, down_i, reset_2;
   logic [3:0] count_o, count_o_expected;
   logic [31:0] iter, iter_up, iter_down;

   nonsynth_clock_gen #(.cycle_time_p(10)) cg (.clk_o(clk_i));
   nonsynth_reset_gen #(.reset_cycles_lo_p(3),.reset_cycles_hi_p(10)) rg(.clk_i(clk_i),.async_reset_o(reset_i));

   counter #() 
   counter_i (.clk_i(clk_i), .reset_i(reset_i  || reset_2), .up_i(up_i), .down_i(down_i), .count_o(count_o));
   
   counter_real #(.width_p(4), .reset_val_p('0)) 
   counter_real (.clk_i(clk_i), .reset_i(reset_i || reset_2), .up_i(up_i), .down_i(down_i), .count_o(count_o_expected));
   

  always_ff@(posedge clk_i) begin
    if(reset_i) begin
        if(count_o !== '0) begin
        assign fail = 1;
        $display("FAILED: count_o_expected: %b, count_o: %b", count_o_expected, count_o);
      end  
    end
    else if(~reset_i) begin
      if(count_o !== count_o_expected) begin
        assign fail = 1;
        $display("FAILED: count_o_expected: %b, count_o: %b", count_o_expected, count_o);
      end  
    end
  end

   initial begin
      // Call this to set pass_o and error_o to 0.
      `START_TESTBENCH
      assign fail = 0;
      reset_2 = 0;
      up_i = 1;
      down_i = 0;

      @(negedge clk_i);
      reset_2 = 1;
      @(posedge clk_i);
      @(posedge clk_i);
      reset_2 = 0;

      @(negedge reset_i);
      @(posedge clk_i);

      for(iter_up = 0; iter_up < 16; iter_up++) begin
        assign up_i = 1;
        @(negedge clk_i);
      end
      for(iter_down = 0; iter_down < 16; iter_down++) begin
        assign down_i = 1;
        @(negedge clk_i);
      end
      for(iter = 0; iter < 5; iter++) begin
        assign up_i = 1;
        assign down_i = 1;
        @(negedge clk_i);
      end
      for(iter = 0; iter < 20; iter++) begin
        assign up_i = iter[0];
        assign down_i = iter[1];
        @(negedge clk_i);
      end
      for(iter = 0; iter < 20; iter++) begin
        assign down_i = iter[0];
        assign up_i = iter[1];
        @(negedge clk_i);
      end
      @(posedge clk_i);
      assign down_i = 0;
      assign up_i = 1;
      @(posedge clk_i);
      @(posedge clk_i);
      @(posedge clk_i);
      @(posedge clk_i);
      @(posedge clk_i);
      @(negedge clk_i);
      reset_2 = 1;
      @(posedge clk_i);
      @(posedge clk_i);
      reset_2 = 0;

      if(fail) begin
         `FINISH_WITH_FAIL;
      end else if(~fail) begin
      `FINISH_WITH_PASS;
      end
   end

   // This block executes after $finish() has been called.
   final begin
      $display("Simulation time is %t", $time);
      if(error_o === 1) begin
	 $display("\033[0;31m    ______                    \033[0m");
	 $display("\033[0;31m   / ____/_____________  _____\033[0m");
	 $display("\033[0;31m  / __/ / ___/ ___/ __ \\/ ___/\033[0m");
	 $display("\033[0;31m / /___/ /  / /  / /_/ / /    \033[0m");
	 $display("\033[0;31m/_____/_/  /_/   \\____/_/     \033[0m");
	 $display("Simulation Failed");
     end else if (pass_o === 1) begin
	 $display("\033[0;32m    ____  ___   __________\033[0m");
	 $display("\033[0;32m   / __ \\/   | / ___/ ___/\033[0m");
	 $display("\033[0;32m  / /_/ / /| | \\__ \\\__ \ \033[0m");
	 $display("\033[0;32m / ____/ ___ |___/ /__/ / \033[0m");
	 $display("\033[0;32m/_/   /_/  |_/____/____/  \033[0m");
	 $display();
	 $display("Simulation Succeeded!");
     end else begin
        $display("   __  ___   ____ __ _   ______ _       ___   __");
        $display("  / / / / | / / //_// | / / __ \\ |     / / | / /");
        $display(" / / / /  |/ / ,<  /  |/ / / / / | /| / /  |/ / ");
        $display("/ /_/ / /|  / /| |/ /|  / /_/ /| |/ |/ / /|  /  ");
        $display("\\____/_/ |_/_/ |_/_/ |_/\\____/ |__/|__/_/ |_/   ");
	$display("Please set error_o or pass_o!");
     end
   end

endmodule
