`timescale 1ns/1ps

// 1 - pass
// 2 - follows ~RESET 
// 3 - follows ~en_i
// 4 - pass
// 5 - reset is asynchronous


`define START_TESTBENCH error_o = 0; pass_o = 0; #10;
`define FINISH_WITH_FAIL error_o = 1; pass_o = 0; #10; $finish();
`define FINISH_WITH_PASS pass_o = 1; error_o = 0; #10; $finish();
module testbench
  // You don't usually have ports in a testbench, but we need these to
  // signal to cocotb/gradescope that the testbench has passed, or failed.
  (output logic error_o = 1'bx
  ,output logic pass_o = 1'bx);

   // You can use this 
   logic [0:0] error;
   
   wire        clk_i;
   wire        reset_i;
   wire        q_o;
   logic en_i, d_i, q_o_expected, fail, reset_2;

   logic [31:0] itervar;
   nonsynth_clock_gen #(.cycle_time_p(10)) cg (.clk_o(clk_i));
   nonsynth_reset_gen #(.reset_cycles_lo_p(1) ,.reset_cycles_hi_p(10)) rg (.clk_i(clk_i) ,.async_reset_o(reset_i));

  dff #() dut (.clk_i(clk_i) ,.reset_i(reset_i || reset_2), .en_i(en_i), .d_i(d_i), .q_o(q_o));

   always_ff @(posedge clk_i) begin
      if(reset_i) begin
	      q_o_expected <= '0;
      end else if (en_i) begin
	      q_o_expected <= d_i;
      end
   end


  always_ff@(posedge clk_i) begin
    if(reset_i) begin
      if(q_o != '0) begin
        assign fail = 1;
        $display("FAILED: q_o_expected: %b, q_o: %b", '0, q_o);
      end  
    end
    else begin
      if(q_o != q_o_expected) begin
        assign fail = 1;
        $display("FAILED: q_o_expected: %b, q_o: %b", q_o_expected, q_o);
      end  
    end
  end


   initial begin
      // Call this to set pass_o and error_o to 0.
      `START_TESTBENCH
      assign reset_2 = 0;
      assign fail = 0;
      assign d_i = 'x;

      @(negedge clk_i);
      assign d_i = '0;
      assign en_i = '0;

      for(itervar = 0; itervar < 'd4; itervar++) begin
        @(negedge clk_i);
        assign d_i = itervar[0];
        assign en_i = ~itervar[1];
        $display("D: d_i: %b, en_i: %b", d_i, en_i);     
      end      

      @(negedge reset_i);
      assign en_i = 1;
      assign d_i = 1;
      @(negedge clk_i);
      @(posedge clk_i);


      assign en_i = 1;
      for(itervar = 0; itervar < 'd5; itervar++) begin
        @(negedge clk_i);
        assign d_i = itervar[0];
        $display("D: d_i: %b, en_i: %b", d_i, en_i);
      end
      assign en_i = 0;
      for(itervar = 0; itervar < 'd5; itervar++) begin
        @(negedge clk_i);
        assign d_i = itervar[0];
        $display("D: d_i: %b, en_i: %b", d_i, en_i);
      end
      assign en_i = 1;
      for(itervar = 0; itervar < 'd4; itervar++) begin
        @(negedge clk_i);
        assign d_i = itervar[1];
        $display("D: d_i: %b, en_i: %b", d_i, en_i);
      end
      assign en_i = 0;
      for(itervar = 0; itervar < 'd5; itervar++) begin
        @(negedge clk_i);
        assign d_i = itervar[1];
        $display("D: d_i: %b, en_i: %b", d_i, en_i);
      end

      @(posedge clk_i);
      @(negedge clk_i);
      assign reset_2 = 1;
      assign d_i = 1;
      assign en_i =1;
      @(posedge clk_i);
      if(q_o === '0) begin
        assign fail = 1;
        $display("FAILED_async_reset_test: q_o_expected: %b, q_o: %b", q_o_expected, q_o);
      end
      @(negedge clk_i);
      @(posedge clk_i);


      if(fail) begin
         `FINISH_WITH_FAIL;
      end else if(~fail) begin
      `FINISH_WITH_PASS;
      end
   end

   // This block executes after $finish() has been called.
   final begin
      $display("Simulation time is %t", $time);
      if(error_o === 1) begin
	 $display("\033[0;31m    ______                    \033[0m");
	 $display("\033[0;31m   / ____/_____________  _____\033[0m");
	 $display("\033[0;31m  / __/ / ___/ ___/ __ \\/ ___/\033[0m");
	 $display("\033[0;31m / /___/ /  / /  / /_/ / /    \033[0m");
	 $display("\033[0;31m/_____/_/  /_/   \\____/_/     \033[0m");
	 $display("Simulation Failed");
     end else if (pass_o === 1) begin
	 $display("\033[0;32m    ____  ___   __________\033[0m");
	 $display("\033[0;32m   / __ \\/   | / ___/ ___/\033[0m");
	 $display("\033[0;32m  / /_/ / /| | \\__ \\\__ \ \033[0m");
	 $display("\033[0;32m / ____/ ___ |___/ /__/ / \033[0m");
	 $display("\033[0;32m/_/   /_/  |_/____/____/  \033[0m");
	 $display();
	 $display("Simulation Succeeded!");
     end else begin
        $display("   __  ___   ____ __ _   ______ _       ___   __");
        $display("  / / / / | / / //_// | / / __ \\ |     / / | / /");
        $display(" / / / /  |/ / ,<  /  |/ / / / / | /| / /  |/ / ");
        $display("/ /_/ / /|  / /| |/ /|  / /_/ /| |/ |/ / /|  /  ");
        $display("\\____/_/ |_/_/ |_/_/ |_/\\____/ |__/|__/_/ |_/   ");
	$display("Please set error_o or pass_o!");
     end
   end

endmodule