module rgb2gray
  #(
   // This is here to help, but we won't change it.
   parameter width_p = 8
   )
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [0:0] valid_i
  ,input [width_p - 1:0] red_i
  ,input [width_p - 1:0] blue_i
  ,input [width_p - 1:0] green_i
  ,output [0:0] ready_o

  ,output [0:0] valid_o
  ,output [width_p - 1:0] gray_o
  ,input [0:0] ready_i
  );

   // The testbench uses this function to test your code. How many
   // fractional bits are needed to enode these values?

   // gray = 0.2989 * r + 0.5870 * g + 0.1140 * b

  localparam FRAC = 20;
  logic [width_p-1:-FRAC] red_conversion, green_conversion, blue_conversion;
  assign red_conversion = {{width_p{1'b0}},  20'b0100_1100_1000_0100_1011};
  assign green_conversion = {{width_p{1'b0}},20'b1001_0110_0100_0101_1010};
  assign blue_conversion = {{width_p{1'b0}}, 20'b0001_1101_0010_1111_0001};

  logic signed [width_p-1:-FRAC] red_mult_i, green_mult_i, blue_mult_i;  //width == width_p + 0 + 0 + |-13| 
  assign red_mult_i = red_i * red_conversion;
  assign green_mult_i = green_i * green_conversion;
  assign blue_mult_i = blue_i * blue_conversion;

  //first I need to multiply
  //if first handshake, compute multiplication of bits
  logic signed [width_p-1:-FRAC] red_mult_o, green_mult_o, blue_mult_o;
  logic ready_add_2_mult, valid_mult_2_add; 
  elastic #(.width_p(width_p+FRAC)) mult_handshake (.clk_i(clk_i), .reset_i(reset_i), 
    .data_1(red_mult_i), .data_2(green_mult_i), .data_3(blue_mult_i),
    .data_o_1(red_mult_o), .data_o_2(green_mult_o), .data_o_3(blue_mult_o),
    .valid_i(valid_i), .ready_o(ready_o),
    .valid_o(valid_mult_2_add), .ready_i(ready_add_2_mult));

  //Once multiplication is done, recive handshake to add
  //Add using pipeline
  logic signed [width_p-1:-FRAC] red_add_o, green_add_o, blue_add_o;
  elastic #(.width_p(width_p+FRAC)) add_handshake (.clk_i(clk_i), .reset_i(reset_i), 
    .data_1(red_mult_o), .data_2(green_mult_o), .data_3(blue_mult_o),
    .data_o_1(red_add_o), .data_o_2(green_add_o), .data_o_3(blue_add_o),
    .valid_i(valid_mult_2_add), .ready_o(ready_add_2_mult),
    .valid_o(valid_o), .ready_i(ready_i));
  //trunkate bits and output ready
  /*verilator lint_off UNUSEDSIGNAL*/
  logic signed [width_p-1:-FRAC] grey_temp;
  /*verilator lint_off UNUSEDSIGNAL*/
  assign grey_temp = red_add_o + green_add_o + blue_add_o;
  assign gray_o = grey_temp[width_p-1:0];

endmodule

