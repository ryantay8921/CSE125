module elastic
  #(parameter [31:0] width_p = 8)
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [width_p - 1:0] data_1
  ,input [width_p - 1:0] data_2
  ,input [width_p - 1:0] data_3
  ,input [0:0] valid_i
  ,output [0:0] ready_o 

  ,output [0:0] valid_o 
  ,output [width_p - 1:0] data_o_1 
  ,output [width_p - 1:0] data_o_2 
  ,output [width_p - 1:0] data_o_3 
  ,input [0:0] ready_i
  );

   logic [width_p-1:0] data_transfer_1, data_transfer_2, data_transfer_3;
   logic valid_temp;

   always_ff @(posedge clk_i) begin
      if(reset_i) begin
	      data_transfer_1 <= {width_p{1'b0}};
         data_transfer_2 <= {width_p{1'b0}};
	      data_transfer_3 <= {width_p{1'b0}};
      end else if(ready_o && valid_i) begin
            data_transfer_1 <= data_1;
            data_transfer_2 <= data_2;
            data_transfer_3 <= data_3;
      end
   end

   always_ff @(posedge clk_i) begin
      if(reset_i) begin
        valid_temp <= 1'b0;
      end else if(ready_o && valid_i) begin
         valid_temp <= ready_o && valid_i;
      end
   end
   
   assign data_o_1 = data_transfer_1; 
   assign data_o_2 = data_transfer_2; 
   assign data_o_3 = data_transfer_3; 

   assign valid_o = valid_temp;
   assign ready_o = ~valid_o || ready_i;
endmodule
