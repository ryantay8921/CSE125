/*verliator Lint_Off PINCONNECTEMPTY */
module delaybuffer
  #(parameter [31:0] width_p = 8
   ,parameter [31:0] delay_p = 8
   )
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [width_p - 1:0] data_i
  ,input [0:0] valid_i
  ,output [0:0] ready_o 

  ,output [0:0] valid_o 
  ,output [width_p - 1:0] data_o 
  ,input [0:0] ready_i
  );

  logic [width_p-1:0] data_shift [delay_p:0];
  logic valid_temp;
  always_ff @(posedge clk_i) begin
   if (valid_i & ready_o) begin
    if(reset_i) begin
      data_shift[0] <= '0;
    end
    data_shift[0] <= data_i;
    for (int i = 1; i <= delay_p; i = i + 1) begin
      if (reset_i) begin
        data_shift[i] <= '0;
      end else begin
      data_shift[i] <= data_shift[i-1];
      end
    end
   end
  end

   always_ff @(posedge clk_i) begin
      if(reset_i) begin
        valid_temp <= 1'b0;
      end
      else if(ready_o) begin
          valid_temp <= ready_o && valid_i;
      end
   end

   assign valid_o = valid_temp;
   assign ready_o = ~valid_o || ready_i;
   assign data_o = data_shift[delay_p];

    generate
  		for (genvar j = 0; j <= delay_p; j++)
                  wire [width_p-1:0] temp = data_shift[j];
   	endgenerate
endmodule
