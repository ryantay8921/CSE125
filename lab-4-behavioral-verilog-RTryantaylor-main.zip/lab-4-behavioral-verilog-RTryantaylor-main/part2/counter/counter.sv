module counter
  #(parameter [31:0] max_val_p = 15
   ,parameter width_p = $clog2(max_val_p)  
    /* verilator lint_off WIDTHTRUNC */
   ,parameter [width_p-1:0] reset_val_p = '0
    /* verilator lint_on WIDTHTRUNC */
    )
   (input [0:0] clk_i
   ,input [0:0] reset_i
   ,input [0:0] up_i
   ,input [0:0] down_i
   ,output [width_p-1:0] count_o);

   localparam [width_p-1:0] max_val_lp = max_val_p[width_p-1:0];

   logic [width_p-1:0] count_next;
   logic [width_p-1:0] count_temp;
   always_ff @(posedge clk_i) begin
     if (reset_i) begin
       count_temp <= reset_val_p; 
     end else begin
       count_temp <= count_next;
     end
   end

  always_comb begin
    count_next = count_temp;
    if (up_i && !down_i) begin
      count_next = (count_temp == max_val_lp) ? '0 : count_temp + 1;
    end else if (down_i && !up_i) begin
       count_next = (count_temp == 0) ? max_val_lp : count_temp - 1; 
    end
  end

  assign count_o = count_temp;
endmodule
