module delaybuffer
  #(parameter [31:0] width_p = 8
   ,parameter [31:0] delay_p = 8
   )
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [width_p - 1:0] data_i
  ,input [0:0] valid_i
  ,output [0:0] ready_o 

  ,output [0:0] valid_o 
  ,output [width_p - 1:0] data_o 
  ,input [0:0] ready_i
  );
  logic [$clog2(delay_p)-1:0] count;
  logic valid, valid_temp;
  
  ram_1r1w_sync #(.width_p(width_p), .depth_p(delay_p), .filename_p("RAMdelay.hex"))
  ram (.clk_i(clk_i), .reset_i(reset_i),
    .wr_valid_i(valid),
    .wr_data_i(data_i),
    .wr_addr_i(count),
    .rd_valid_i(valid),
    .rd_addr_i(count),
    .rd_data_o(data_o));

  assign ready_o = ~valid_o | ready_i;
  assign valid_o =  valid_temp;
  assign valid = valid_i && ready_o;

  always_ff @(posedge clk_i) begin
    if(reset_i) begin
      count <= '0;
      valid_temp <= 1'b0;
    end else begin
      if(ready_o) begin;
        valid_temp <= ready_o & valid_i;
      end
      if(valid) begin
      /* verilator lint_off WIDTHEXPAND */
      count <= (count == (delay_p - 1)) ? 0 : count + 1;
      /* verilator lint_on WIDTHEXPAND */
      end
    end
  end


endmodule
