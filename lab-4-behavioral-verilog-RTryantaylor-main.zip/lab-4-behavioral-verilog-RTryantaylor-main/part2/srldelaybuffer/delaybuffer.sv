module delaybuffer
  #(parameter [31:0] width_p = 8
   ,parameter [31:0] delay_p = 8
   )
  (input [0:0] clk_i
  ,input [0:0] reset_i

  ,input [width_p - 1:0] data_i
  ,input [0:0] valid_i
  ,output [0:0] ready_o 

  ,output [0:0] valid_o 
  ,output [width_p - 1:0] data_o 
  ,input [0:0] ready_i
  );

    logic [width_p-1:0] srl_output;
    logic valid_temp, Clock_Enable;

  always_ff @(posedge clk_i) begin
    if (reset_i) begin
      valid_temp <= 1'b0;
    end else if (ready_o) begin
      valid_temp <= valid_i;
    end
  end
  assign valid_o = valid_temp;
  assign ready_o = ~valid_o | ready_i;
  assign Clock_Enable = valid_i && ready_o;
  genvar i;
  generate
    for (i = 0; i < width_p; i++) begin : gen_srl
      SRL16E #(.INIT(16'h0000)) 
      srl_inst (.Q(srl_output[i]), .CLK(clk_i), .CE(Clock_Enable), .D(data_i[i]),
                .A0(delay_p[0]), .A1(delay_p[1]), .A2(delay_p[2]), .A3(delay_p[3]));
    end
  endgenerate
  assign data_o = srl_output;
endmodule
