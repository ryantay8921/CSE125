/*verilator lint_off WIDTHEXPAND*/
/*verilator lint_off WIDTHTRUNC*/
/*verilator lint_off UNUSEDSIGNAL*/
/*verilator lint_off SYNCASYNCNET*/
module adder
  #(parameter width_p = 32)
  (input [0:0] clk_i,
   input [0:0] reset_i,
   input [0:0] valid_i,
   input signed [width_p-1:0] a_i,
   input signed [width_p-1:0] b_i,
   output [0:0] ready_o,
   output [0:0] valid_o,
   output signed [width_p:0] c_o,
   input [0:0] ready_i);

  // Intermediate signals for DSP48A1
  logic CLK;
  logic CARRYIN;
  logic [7:0] OPMODE;
  logic RSTA, RSTB, RSTM, RSTP, RSTC, RSTD, RSTCARRYIN, RSTOPMODE;
  logic CEA, CEB, CEM, CEP, CEC, CED, CECARRYIN, CEOPMODE;
  logic [47:0] PCIN;
  logic [17:0] BCOUT;
  logic [47:0] PCOUT;
  logic [32:0] P;
  logic [35:0] M;
  logic CARRYOUT;
  logic CARRYOUTF;
  logic [17:0] A, B, D;
  logic [31:0] C;

  logic [32:0] a_signed;
  assign a_signed= $signed(a_i);
  logic [32:0] b_signed;
  assign b_signed = $signed(b_i);

  // Assigning DSP inputs
  assign A = {'0, b_signed[31:18]};
  assign B = {'0, b_signed[17:0]};
  assign C = {'0, a_signed[32:0]};
  assign D = {18{1'b0}};
  assign CLK = clk_i; // Using clk_i for DSP clock
  assign CARRYIN = 1'b0;
  assign OPMODE = 8'b0_0_0_0_11_11; // Operation mode for addition
  // 7 : 0 add; 1 subtract
  // 6 : 0 pre-add, 1 pre-sub
  // 5 : 0 no carry_in force, 1 carry_in
  // 4 : 0 bypass pre-adder, 1 pre-adds
  // 32: 00 disable, 01 PCIN, 10 PCout(accumulator), 11 C port
  // 10: 00 disable post-adder, 01 use mult product, 10 PCout(accumulator, 11 use concatenated D:A:B signals
  assign RSTA = reset_i; // Reset signals
  assign RSTB = reset_i;
  assign RSTM = reset_i;
  assign RSTP = reset_i;
  assign RSTC = reset_i;
  assign RSTD = reset_i;
  assign RSTCARRYIN = reset_i;
  assign RSTOPMODE = reset_i;
  assign CEA = 1'b0; // DONT USE A1 REG
  assign CEB = 1'b0; // DONT USE B1 REG
  assign CEM = 1'b0; // DONT USE M REG
  assign CEP = ready_o && valid_i;
  assign CEC = 1'b0;
  assign CED = 1'b0;
  assign CECARRYIN = 1'b0;
  assign CEOPMODE = 1'b1;
  assign PCIN = 48'b0; // Clearing PCIN input

  // DSP48A1 Instance
  DSP48A1 #(
    .A0REG(1'b0), // Registered
    .A1REG(1'b0), // No register
    .B0REG(1'b0), // Registered
    .B1REG(1'b0), // No register
    .CREG(1'b0), // Registered
    .DREG(1'b0), // Registered
    .MREG(1'b0), // No register
    .PREG(1'b1), // No register
    .CARRYINREG(1'b0), // No register
    .CARRYOUTREG(1'b0), // No register
    .OPMODEREG(1'b0), // No register
    .CARRYINSEL("OPMODE5"), // CARRYIN selection
    .B_INPUT("DIRECT"), // Direct input
    .RSTTYPE("SYNC") // Synchronous reset
  ) dsp_inst (
    .A(A),
    .B(B),
    .D(D),
    .C(C),
    .CLK(CLK),
    .CARRYIN(CARRYIN),
    .OPMODE(OPMODE),
    .RSTA(RSTA),
    .RSTB(RSTB),
    .RSTM(RSTM),
    .RSTP(RSTP),
    .RSTC(RSTC),
    .RSTD(RSTD),
    .RSTCARRYIN(RSTCARRYIN),
    .RSTOPMODE(RSTOPMODE),
    .CEA(CEA),
    .CEB(CEB),
    .CEM(CEM),
    .CEP(CEP),
    .CEC(CEC),
    .CED(CED),
    .CECARRYIN(CECARRYIN),
    .CEOPMODE(CEOPMODE),
    .PCIN(PCIN),
    .BCOUT(BCOUT),
    .PCOUT(PCOUT),
    .P(P),
    .M(M),
    .CARRYOUT(CARRYOUT),
    .CARRYOUTF(CARRYOUTF)
  );

  assign c_o = P[width_p:0];

  logic valid_temp;
  always_ff @(posedge clk_i) begin
    if (reset_i) begin
      valid_temp <= '0;
    end else if (ready_o) begin
      valid_temp <= valid_i; // Set valid if ready
    end
  end

  assign ready_o = ~valid_o | ready_i;
  assign valid_o = valid_temp;
endmodule
