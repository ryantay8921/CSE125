module multiplier
  #(parameter width_p = 11)
   (input [0:0] clk_i
   ,input [0:0] reset_i
    // Input Interface
   ,input [0:0] valid_i
   ,output [0:0] ready_o
   ,input [width_p - 1 : 0] a_i
   ,input [width_p - 1 : 0] b_i

   // Output Interface
   ,output [0 : 0] valid_o
   ,input [0 : 0] ready_i
   ,output [(2 * width_p) - 1 : 0] result_o);
   
   
    // Internal registers for processing
    reg [2*width_p-1:0] product_reg;
    reg [2*width_p-1:0] multiplicand_reg;
    reg [width_p-1:0] shift_reg;  
    reg [width_p-1:0] counter;
    
    // Intermediate logic variables for outputs
    logic ready_o_int, valid_o_int;
    logic [2*width_p-1:0] result_o_int;

    // Assign intermediate variables to outputs
    assign ready_o = ready_o_int;
    assign valid_o = valid_o_int;
    assign result_o = result_o_int;

    // State machine states
    typedef enum {IDLE, COMPUTE, FINISH} state_t;
    state_t state;

    always @(posedge clk_i) begin
        if (reset_i) begin
            // Reset internal state
            state <= IDLE;
            valid_o_int <= 0;
            ready_o_int <= 1;
            product_reg <= 0;
            counter <= 0;
        end else begin
            case (state)
                IDLE: begin
                    if (ready_o_int && valid_i) begin
                        // Load operands and start computation
                        multiplicand_reg <= { {(width_p){1'b0}}, b_i };
                        shift_reg <= a_i;
                        product_reg <= 0;
                        counter <= width_p;  // Set the counter for shifting process
                        state <= COMPUTE;
                        ready_o_int <= 0;
                    end
                end
                COMPUTE: begin
                    if (counter > 0) begin
                        // Check if the LSB of shift_reg is 1
                        if (shift_reg[0] == 1'b1) begin
                            product_reg <= product_reg + multiplicand_reg;
                        end
                        // Shift operations
                        multiplicand_reg <= multiplicand_reg << 1;
                        shift_reg <= shift_reg >> 1;
                        counter <= counter - 1;
                    end else begin
                        state <= FINISH;
                    end
                end
                FINISH: begin
                    result_o_int <= product_reg;
                    valid_o_int <= 1;
                    if (ready_i && valid_o_int) begin
                        state <= IDLE;
                        ready_o_int <= 1;
                        valid_o_int <= 0;
                    end
                end
            endcase
        end
    end

endmodule
