module imanok
   (input [0:0] clk_i
   ,input [0:0] start_i
   ,input [0:0] unstart_i
   ,input [0:0] a_i
   ,input [0:0] una_i
   ,input [0:0] b_i
   ,input [0:0] unb_i
   ,input [0:0] right_i
   ,input [0:0] unright_i
   ,input [0:0] left_i
   ,input [0:0] unleft_i
   ,input [0:0] down_i
   ,input [0:0] undown_i
   ,input [0:0] up_i
   ,input [0:0] unup_i
   ,input [0:0] reset_i
   ,output [0:0] cheat_code_unlocked_o
   ,output [31:0] state_o);

   typedef enum int {
      IDLE,
      STARTP, STARTUP,
      AP, AUP,
      BP, BUP,
      R1P, R1UP,
      L1P, L1UP,
      R2P, R2UP,
      L2P, L2UP,
      D1P, D1UP,
      D2P, D2UP,
      U1P, U1UP,
      U2P,
      CODE_UNLOCKED
   } state_t;
   state_t  curr_state, next_state;
always_ff @(posedge clk_i ) begin : dffs
    if (reset_i) begin
        curr_state <= IDLE;
    end else begin 
        curr_state <= next_state; 
    end
end
        assign state_o = curr_state;

    logic cheat_code_unlocked_int;
    assign cheat_code_unlocked_o = cheat_code_unlocked_int;
    always_comb begin cheat_code_unlocked_int = (curr_state == CODE_UNLOCKED); end


always_comb begin
    next_state = curr_state;
    case (curr_state)
        IDLE: begin
            if (start_i) next_state = STARTP; // Transition on start button press
               else if(a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;
            else next_state = IDLE;
        end
        STARTP: begin
            if (unstart_i) next_state = STARTUP;
                else if(a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;
            else next_state = curr_state;
        end
        STARTUP: begin
            if (a_i) next_state = AP;
            else if (start_i) next_state = STARTP;
                else if(unstart_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else next_state = curr_state;
        end
        AP: begin
            if (una_i) next_state = AUP;
                else if(unstart_i||a_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = AP;
            else next_state = curr_state;
        end
        AUP: begin
            if (b_i) next_state = BP;
                else if(unstart_i||a_i||una_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        BP: begin
            if (unb_i) next_state = BUP;
                else if(unstart_i||a_i||una_i||b_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        BUP: begin
            if (right_i) next_state = R1P;
                else if(unstart_i||a_i||una_i||b_i||unb_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        R1P: begin
            if (unright_i) next_state = R1UP;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        R1UP: begin
            if (left_i) next_state = L1P;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        L1P: begin
            if (unleft_i) next_state = L1UP;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        L1UP: begin
            if (right_i) next_state = R2P;
                else if(unstart_i||a_i||una_i||b_i||unb_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        R2P: begin
            if (unright_i) next_state = R2UP;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        R2UP: begin
            if (left_i) next_state = L2P;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        L2P: begin
            if (unleft_i) next_state = L2UP;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        L2UP: begin
            if (down_i) next_state = D1P;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        D1P: begin
            if (undown_i) next_state = D1UP;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        D1UP: begin
            if (down_i) next_state = D2P;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        D2P: begin
            if (undown_i) next_state = D2UP;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||up_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        D2UP: begin
            if (up_i) next_state = U1P;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        U1P: begin
            if (unup_i) next_state = U1UP;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        U1UP: begin
            if (up_i) next_state = U2P;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||unup_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        U2P: begin
            if (unup_i) next_state = CODE_UNLOCKED;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i) next_state = IDLE;            
                else if (start_i) next_state = STARTP;
            else next_state = curr_state;
        end
        CODE_UNLOCKED: begin
            if (start_i) next_state = STARTP;
                else if(unstart_i||a_i||una_i||b_i||unb_i||right_i||unright_i||left_i||unleft_i||down_i||undown_i||up_i||unup_i) next_state = IDLE;            
                else next_state = curr_state;
        end
    endcase
end

endmodule
