module detect_edge
   (input [0:0] clk_i
    // reset_i will go low at least one cycle before a button is pushed.
   ,input [0:0] reset_i
   ,input [0:0] button_i
    // Should go high for 1 cycle, after a positive edge
   ,output [0:0] button_o
    // Should go high for 1 cycle, after a negative edge
   ,output [0:0] unbutton_o
   );
   logic button_prev;
   logic button_temp, unbutton_temp;
   logic button_next, unbutton_next;

   always_ff @(posedge clk_i) begin
      
      if(reset_i) begin
         button_prev <= 1'b0;
         button_temp <= 1'b0;
         unbutton_temp <= 1'b0;
      end else begin
         button_temp <= button_next;
         unbutton_temp <= unbutton_next;

         button_prev <= button_i;
      end
   end

   always_comb begin
        button_next = 1'b0;
        unbutton_next = 1'b0;
      if(button_i && !button_prev) begin
         button_next = 1'b1;
      end else if (!button_i && button_prev) begin
         unbutton_next = 1'b1;
      end
   end

   assign button_o = button_temp;
   assign unbutton_o = unbutton_temp;

endmodule
