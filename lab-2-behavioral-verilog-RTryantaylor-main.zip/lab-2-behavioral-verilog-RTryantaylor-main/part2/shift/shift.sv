module shift
  #(parameter width_p = 5
    /* verilator lint_off WIDTHTRUNC */
   ,parameter [width_p-1:0] reset_val_p = '0)
   /* verilator lint_on WIDTHTRUNC */   
   (input [0:0] clk_i
   ,input [0:0] reset_i
   ,input [0:0] en_i
   ,input [0:0] d_i
   ,input [0:0] load_i
   ,input [width_p-1:0] data_i
   ,output [width_p-1:0] data_o);

   logic [width_p-1:0] data_next;
   logic [width_p-1:0] data_temp;
   always_ff @(posedge clk_i) begin
     if (reset_i) begin
       data_temp <= reset_val_p; 
     end else if(load_i) begin
       data_temp <= data_i;
     end else if(en_i) begin
       data_temp <= data_next;
     end
   end

   always_comb begin                   
    data_next = {data_temp[width_p-2:0], d_i};
   end

   assign data_o = data_temp;
endmodule
