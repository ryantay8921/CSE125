module debounce
  #(parameter min_delay_p = 4
    )
   (input [0:0] clk_i
   ,input [0:0] reset_i
   ,input [0:0] button_i
   ,output [0:0] button_o);

  localparam width_p = 1 << ($clog2(min_delay_p) + 1);
  wire [width_p-1:0] shift_o;
  shift #(.width_p(width_p), .reset_val_p(0))
  shift_reg (.clk_i(clk_i), .reset_i(reset_i), .en_i(1'b1), .d_i(button_i), .load_i(1'b0), .data_i('0), .data_o(shift_o));
  logic button_temp;
  logic button_next;
  always_ff @(posedge clk_i) begin
    if(reset_i) begin
      button_temp <= 1'b0;
    end else
      button_temp <= button_next;
  end

  always_comb begin
    if(shift_o[min_delay_p]) begin
      button_next = 1'b1;
    end else if(shift_o == 0) begin 
      button_next = 1'b0;
    end else
      button_next = 1'b0;
  end
  assign button_o = button_temp;
endmodule
