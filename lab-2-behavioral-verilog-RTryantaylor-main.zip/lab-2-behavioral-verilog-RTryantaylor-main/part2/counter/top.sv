// Top-level design file for the icebreaker FPGA board
module top
  (input [0:0] clk_12mhz_i
  ,input [0:0] reset_n_async_unsafe_i
   // n: Negative Polarity (0 when pressed, 1 otherwise)
   // async: Not synchronized to clock
   // unsafe: Not De-Bounced
  ,input [3:1] button_async_unsafe_i
   // async: Not synchronized to clock
   // unsafe: Not De-Bounced
  ,output [7:0] ssd_o
  ,output [5:1] led_o);

   // For this demonstration, instantiate your Counter modules to
   // drive the output wires of ssd_o. You may only use structural
   // verilog, the modules in provided_modules, and your lfsr module,
   // and your counter.
   // 
   wire [0:0] reset_n_sync_r;
   wire [0:0] reset_sync_r;
   wire [0:0] reset_r; // Use this as your reset_signal
   dff #() sync_a( .clk_i(clk_12mhz_i), .reset_i(1'b0), .en_i(1'b1), .d_i(reset_n_async_unsafe_i), .q_o(reset_n_sync_r));
   inv #() inv (.a_i(reset_n_sync_r), .b_o(reset_sync_r));
   dff #() sync_b( .clk_i(clk_12mhz_i), .reset_i(1'b0), .en_i(1'b1), .d_i(reset_sync_r), .q_o(reset_r));
       

  wire [21:0] count_clk;
  counter #(.width_p(22)) time_counter(.clk_i(clk_12mhz_i), .reset_i(reset_r), .up_i(1'b1), .down_i(1'b0), .count_o(count_clk));

  wire btn_up, btn_down, btn_up_debounced, btn_down_debounced;
  detect_edge #() detect_edge_up(.clk_i(clk_12mhz_i), .reset_i(reset_r), .button_i(button_async_unsafe_i[3]), .button_o(btn_up), .unbutton_o());
  debounce #(.min_delay_p(4)) debounce_up(.clk_i(clk_12mhz_i), .reset_i(reset_r), .button_i(btn_up), .button_o(btn_up_debounced));
 
  detect_edge #() detect_edge_down(.clk_i(clk_12mhz_i), .reset_i(reset_r), .button_i(button_async_unsafe_i[1]), .button_o(btn_down), .unbutton_o());
  debounce #(.min_delay_p(4)) debounce_down(.clk_i(clk_12mhz_i), .reset_i(reset_r), .button_i(btn_down), .button_o(btn_down_debounced));

  wire [7:0] count_o;
  counter #(.width_p(8), .reset_val_p('0)) count(.clk_i(clk_12mhz_i), .reset_i(reset_r), .up_i(btn_up_debounced), .down_i(btn_down_debounced), .count_o(count_o));

   wire [6:0] display1, display2, display_o;
   hex2ssd #() hex1(.hex_i(count_o[3:0]), .ssd_o(display1));
   hex2ssd #() hex2(.hex_i(count_o[7:4]), .ssd_o(display2));

   assign ssd_o = {count_clk[10], (count_clk[10]) ? display1 : display2};
   assign led_o = {5{1'b1}};

endmodule
