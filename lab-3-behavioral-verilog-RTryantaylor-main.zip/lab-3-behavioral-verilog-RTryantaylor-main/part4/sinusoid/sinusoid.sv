/* verilator lint_off UNUSEDSIGNAL */

module sinusoid
  (input [0:0] clk_i
  ,input [0:0] reset_i
  ,output signed [11:0] sine_wave_o
   );

   localparam width_p = 12;
   wire [width_p-1:0] counter_addr;  

  ram_1r1w_async #(.width_p(width_p), .depth_p(1024), .filename_p("sine_wave_mem.hex"))
  ram_ (.clk_i(clk_i), .reset_i(reset_i), .rd_addr_i(counter_addr[9:0]), .rd_data_o(sine_wave_o), .wr_valid_i(1'b0), .wr_data_i('0), .wr_addr_i('0));

  localparam counter_width = 6;
   wire [counter_width-1:0] counter;
   wire slow_clk;
   counter #(.width_p(counter_width), .reset_val_p('0))
   counter_time (.clk_i(clk_i), .reset_i(reset_i || slow_clk), .up_i(1'b1), .down_i(1'b0), .count_o(counter));
  //  assign slow_clk = (counter == 6'b11_0111); // 55
   assign slow_clk = (counter == 6'b11_1000); //56


  counter #(.width_p(width_p), .reset_val_p('0))
  counter_address (.clk_i(clk_i), .reset_i(reset_i), .up_i(slow_clk), .down_i(1'b0), .count_o(counter_addr));

/*
15 - 1462
25 - 972
29 - 778
32 - 922
50 - 488
52 - 470
55 - 444
56 - 437
64 - 383
100 - 247
*/

endmodule
