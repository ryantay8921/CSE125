module shift
  #(parameter width_p = 5
    /* verilator lint_off WIDTHTRUNC */
   ,parameter [width_p-1:0] reset_val_p = '0)
   /* verilator lint_on WIDTHTRUNC */   
   (input [0:0] clk_i
   ,input [0:0] reset_i
   ,input [0:0] en_i
   ,input [0:0] d_i
   ,input [0:0] load_i
   ,input [width_p-1:0] data_i
   ,output [width_p-1:0] data_o);

  wire [width_p:0] shift_reg;
  assign shift_reg[0] = d_i;
  genvar i;
  /* verilator lint_off WIDTHTRUNC */
  generate
    for(i = 0 ; i < width_p; i++) begin: shifty
     ICESTORM_LC #(.LUT_INIT(16'h0002), .DFF_ENABLE(1'b1), .SET_NORESET(reset_val_p[i]))
        shift_i (.I0((~load_i & shift_reg[i]) || (load_i & data_i[i])), .I1(1'b0), .I2(1'b0), .I3(1'b0), .CIN(1'b0), .CLK(clk_i), .CEN(en_i | load_i | reset_i), .SR(reset_i)
                  , .LO(), .O(shift_reg[i+1]), .COUT());
    end
  endgenerate
  /* verilator lint_on WIDTHTRUNC */

  assign data_o = shift_reg[width_p:1];



endmodule
