module triadder
  #(parameter width_p = 5)
  // You must fill in the bit widths of a_i, b_i and sum_o. a_i and
  // b_i must be width_p bits.
  (input [width_p-1:0] a_i
  ,input [width_p-1:0] b_i
  ,input [width_p-1:0] c_i
  ,output [width_p+1:0] sum_o);

  wire [width_p+1:0] carry;
  assign carry[0] = 1'b0;
  assign carry[width_p+1] = 1'b0;
  wire [width_p+1:0] sum;
  assign sum[width_p+1:width_p] = 2'b0;

  genvar i;
  generate
    for (i = 0; i < width_p ; i++ ) begin
      full_add #() fa_i (.a_i(a_i[i]), .b_i(b_i[i]), .carry_i(c_i[i]), .carry_o(carry[i+1]), .sum_o(sum[i]));
    end

    assign sum_o = sum + carry;

  endgenerate


endmodule
