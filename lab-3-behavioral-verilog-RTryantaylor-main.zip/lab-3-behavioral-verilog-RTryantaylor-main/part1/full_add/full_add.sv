module full_add
  (input [0:0] a_i
  ,input [0:0] b_i
  ,input [0:0] carry_i
  ,output [0:0] carry_o
  ,output [0:0] sum_o);

    ICESTORM_LC #(.LUT_INIT(16'b0000_0000_1001_0110), .CARRY_ENABLE(1'b1))
    full_add (.I0(carry_i), .I1(a_i), .I2(b_i), .I3(1'b0), .CIN(carry_i), .CLK(1'b0), .CEN(1'b1), .SR(1'b0)
              , .LO(), .O(sum_o), .COUT(carry_o));

endmodule
