module adder
  #(parameter width_p = 5)
  // You must fill in the bit widths of a_i, b_i and sum_o. a_i and
  // b_i must be width_p bits.
  (input [width_p-1:0] a_i
  ,input [width_p-1:0] b_i
  ,output [width_p:0] sum_o);


/*
  localparam number_of_4_bit_groups = (width_p+3)/4; //get parmatized number of carry mods we need

  logic [number_of_4_bit_groups:0] carry_chain; //how many carry wires will we need
  assign carry_chain[0] = 1'b0;
  logic [width_p-1:0] sum;  //sum without the final carry bit so width_p-1

  genvar i;
  for(i = 0; i < number_of_4_bit_groups; i++) begin
    
    CARRY4 #() carry_mod (
        .CO(carry_chain[i+1]), .O(),   //outputs 
        .CI(carry_chain[i]), .DI(), .S(), .CYINIT(1'b0));  //inputs

  end
*/
  assign sum_o = a_i + b_i;

endmodule
