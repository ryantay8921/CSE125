// Top-level design file for the icebreaker FPGA board
//
// Wi23, Lab 3
module top
  (input [0:0] clk_12mhz_i
   // n: Negative Polarity (0 when pressed, 1 otherwise)
   // async: Not synchronized to clock
   // unsafe: Not De-Bounced
  ,input [0:0] reset_n_async_unsafe_i
   // async: Not synchronized to clock
   // unsafe: Not De-Bounced
  ,input [3:0] kpyd_row_i
  ,output [3:0] kpyd_col_o
  ,output [7:0] ssd_o);

   // These two D Flip Flops form what is known as a Synchronizer. We
   // will learn about these in Week 5, but you can see more here:
   // https://inst.eecs.berkeley.edu/~cs150/sp12/agenda/lec/lec16-synch.pdf
   wire reset_n_sync_r;
   wire reset_sync_r;
   wire reset_r; // Use this as your reset_signal
   dff #() sync_a (.clk_i(clk_12mhz_i) ,.reset_i(1'b0) ,.en_i(1'b1) ,.d_i(reset_n_async_unsafe_i) ,.q_o(reset_n_sync_r));
   inv #() inv (.a_i(reset_n_sync_r) ,.b_o(reset_sync_r));
   dff #() sync_b (.clk_i(clk_12mhz_i) ,.reset_i(1'b0) ,.en_i(1'b1) ,.d_i(reset_sync_r) ,.q_o(reset_r));


   wire [11:0] count_clk;
   wire count_max;
   counter #(.width_p(22)) time_counter(.clk_i(clk_12mhz_i), .reset_i(reset_r), .up_i(1'b1), .down_i(1'b0), .count_o(count_clk));
   assign count_max = count_clk == '1;

  logic [3:0] kpyd_col_zero;
  always_ff @(posedge clk_12mhz_i ) begin : shift
      if(reset_r) begin
        kpyd_col_zero <= 4'b0001;
      end
      else if(count_max) begin
        kpyd_col_zero <= {kpyd_col_zero[2:0], kpyd_col_zero[3]};
      end
  end
  assign kpyd_col_o = ~kpyd_col_zero;

   wire [3:0] hex_carry;
   wire [6:0] ssd_out;
   kpyd2hex #() kpyd2hex(.kpyd_i({~kpyd_row_i, ~kpyd_col_o}), .hex_o(hex_carry));
   hex2ssd #() hex2ssd(.hex_i(hex_carry), .ssd_o(ssd_out));


   assign noPress = (kpyd_row_i != 4'b1111);
   assign ssd_o[6:0] = noPress ? ssd_out : 7'b111_1111;
   assign ssd_o[7] = 1'b0;

  endmodule
