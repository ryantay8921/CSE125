module kpyd2hex
  (input [7:0] kpyd_i
  ,output [3:0] hex_o);



  ram_1r1w_async #(.width_p(4), .depth_p(140), .filename_p("/workspaces/lab-3-behavioral-verilog-RTryantaylor/part2/kpyd2hex/kpyd2hex.hex")) 
  ram1(.clk_i(1'b0), .reset_i(1'b0), .wr_valid_i(1'b0), .wr_data_i(4'b0), .wr_addr_i(8'b0),
       .rd_addr_i(kpyd_i),
       .rd_data_o(hex_o));

endmodule
