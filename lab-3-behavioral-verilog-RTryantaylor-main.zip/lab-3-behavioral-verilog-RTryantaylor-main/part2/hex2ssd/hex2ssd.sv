module hex2ssd
  (input [3:0] hex_i
  ,output [6:0] ssd_o
  );

`define hex_test "hex2ssd.hex"
`define hex_bit "/workspaces/lab-3-behavioral-verilog-RTryantaylor/part2/hex2ssd/hex2ssd.hex"

  ram_1r1w_async #(.width_p(7), .depth_p(16), .filename_p("hex2ssd.hex")) 
  ram1(.clk_i(1'b0), .reset_i(1'b0), .wr_valid_i(1'b0), .wr_data_i(7'b0), .wr_addr_i(4'b0),
       .rd_addr_i(hex_i),
       .rd_data_o(ssd_o));

endmodule
